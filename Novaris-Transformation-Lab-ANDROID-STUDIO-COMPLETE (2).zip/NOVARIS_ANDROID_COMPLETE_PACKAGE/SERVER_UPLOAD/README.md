# Novaris Transformation Lab — 8 Free Assessments

**Complete website replacement**, including the mobile-optimised homepage and eight free assessments, the fixed white navigation band, the original Novaris logo and triangle favicon, and the bright workplace photography with local fallback artwork. No intro video, Razorpay, checkout, paid-access, or client admin.

## Participant and Novaris reporting split

1. The visitor selects one of the eight original instruments and completes its questions for free.
2. The browser generates the original instrument's **full-length, author-designed PDF**, with every report page and the original interpretation, graphics, and guidance. This happens behind a submission overlay; there is **no PDF download for the visitor**.
3. For **MEridian** and **EQuilibrium**, the complete report includes **two PDF attachments**: the 10-page Assessment Report and the 4-page Development Plan. The other six tests generate their single complete original report.
4. The website sends those original PDF bytes privately through Titan SMTP to **lead@novaristransformationlab.com**. Results are never sent as raw code in the email body.
5. Only when the mail server accepts the attachments does the visitor see a **short on-screen executive summary**, with key indicators, and no PDF/report download.
6. If generating or emailing **any** original report page/part fails, the visitor sees Retry; the server will **not** replace the original report with a brief generic PDF and will **not** falsely mark it complete.

The instruments retain their authored questions, algorithms, and PDF layouts. Team Latitude remains anonymous by design. The PDF generators run in the participant's browser, meaning a technically knowledgeable user can still inspect source code: this does not establish server-only scoring or cryptographic secrecy.

For required PHP upload limits, local checks and deployment details, see **ORIGINAL-REPORT-DELIVERY.md** and **DEPLOYMENT.md**. The packaged `.env` contains private Titan SMTP settings; keep the ZIP private.
