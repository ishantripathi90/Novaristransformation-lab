/* Single participant submission receipt for all eight Novaris instruments. */
(function(){
  'use strict';
  const meta={
    entronovaris:'Entronovaris™',authorityflow:'NOVARIS AuthorityFlow™',growth_readiness:'Growth-Readiness Matrix™',
    relatiq:'NOVARIS RELATIQ™',team_dynamics:'Team Dynamics Map',team_latitude:'Team Latitude Map',
    meridian:'MEridian™',equilibrium:'EQuilibrium™'
  };
  const test=document.body && document.body.dataset ? document.body.dataset.novarisTest : '';
  const safeName=meta[test]||'Novaris assessment';
  function header(){
    if(document.getElementById('novaris-unified-header'))return;
    const h=document.createElement('header');h.id='novaris-unified-header';
    h.innerHTML='<a href="index.php" aria-label="Novaris Transformation Lab home"><img src="assets/novaris-logo-header.png" alt="Novaris Transformation Lab"></a><div class="novaris-head-right"><span>FREE ASSESSMENT</span><a href="index.php">Exit</a></div>';
    document.body.prepend(h);
  }
  function shield(){
    let el=document.getElementById('novaris-submit-shield');
    if(el)return el;
    el=document.createElement('div');el.id='novaris-submit-shield';el.hidden=true;el.setAttribute('role','status');el.setAttribute('aria-live','polite');
    el.innerHTML='<div class="novaris-shield-card"><div class="novaris-shield-icon">✓</div><div class="novaris-shield-kicker">Final step</div><h2>Submitting your assessment</h2><p>We are securely delivering your response to the Novaris team. Keep this page open until the confirmation appears.</p><button class="novaris-action" type="button" hidden>Retry submission</button></div>';
    document.body.appendChild(el);return el;
  }
  function paint(title,message,retry){
    const el=shield();el.hidden=false;
    el.querySelector('h2').textContent=title;el.querySelector('p').textContent=message;
    const b=el.querySelector('button');b.hidden=!retry;
    if(retry)b.onclick=retry;
  }
  function send(data){
    const state={done:false, busy:false};
    return new Promise(function(resolve){
      async function attempt(){
        if(state.busy||state.done)return;
        state.busy=true;paint('Submitting your assessment','Sending '+safeName+' to Novaris securely. Please keep this page open.',null);
        try{
          if(!window.NovarisOriginalReports||!window.NovarisOriginalReports.create)throw new Error('The original report engine did not load.');
          paint('Preparing your complete report','Generating the original full-length assessment PDF for private delivery to Novaris. This may take a minute on mobile.',null);
          if(!state.reports)state.reports=await window.NovarisOriginalReports.create(data.product);
          const form=new FormData();form.append('data',JSON.stringify(data));
          state.reports.forEach((r,i)=>form.append('reports[]',r.blob,r.name));
          paint('Sending your complete report','Uploading the full original PDF'+(state.reports.length>1?'s':'')+' to Novaris. Please keep this tab open.',null);
          const response=await fetch('save-result.php',{method:'POST',credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'},body:form,cache:'no-store'});
          const result=await response.json().catch(()=>({}));
          if(!response.ok || !result.ok)throw new Error(result.error||'Delivery not confirmed');
          state.done=true;
          paint('Submission received','The Novaris team has received your assessment. Opening the confirmation page…',null);
          resolve(result);
          window.location.replace('submission-receipt.php');
        }catch(err){
          console.warn('Novaris assessment delivery pending:',err);
          paint('Could not confirm delivery',String(err.message||'The report could not be emailed.')+' Your answers remain here. Tap Retry to try again. Do not close this page until confirmation appears.',attempt);
        }finally{state.busy=false;}
      }
      attempt();
    });
  }
  window.NovarisSubmission={post:send,showPending:function(){paint('Submitting your assessment','Please wait while we send your results to Novaris.',null)}};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',header,{once:true});else header();
})();
