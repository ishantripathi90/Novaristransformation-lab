/* Novaris MEridian / EQuilibrium free-site bridge; original scoring preserved. */
(function(){
'use strict';
var el=document.body;
if(!el||!el.dataset)return;
var key=el.dataset.novarisTest;
if(key!=='meridian'&&key!=='equilibrium')return;
var identity=window.NOVARIS_PROFILE_IDENTITY||{};
var sent=false;
function prefill(){
  [['f_name','name'],['f_email','email'],['f_org','company']].forEach(function(pair){
    var input=document.getElementById(pair[0]);
    if(input){input.value=identity[pair[1]]||'';if(pair[0]!=='f_org'){input.readOnly=true;}}
  });
  var message=document.getElementById('novaris-privacy-note');
  if(!message){
    var consent=document.getElementById('f_consent');
    var parent=consent&&consent.closest('label');
    if(parent){
      message=document.createElement('p');message.id='novaris-privacy-note';
      message.textContent='Your responses and detailed PDF report will be sent privately to Novaris Transformation Lab. You will receive a short executive summary on screen.';
      message.style.cssText='font-size:13px;color:#466575;line-height:1.55;background:#edf6f3;border-left:3px solid #138a7e;padding:10px 12px;margin:14px 0';
      parent.parentNode.insertBefore(message,parent.nextSibling);
    }
  }
  var resume=document.getElementById('resumeBox');
  if(resume && resume.classList.contains('hidden')===false) {
    // Only current-attempt drafts can resume. The PHP wrapper changed the storage key.
  }
}
window.novarisNewTestSubmit=function(){
  if(sent)return;
  if(typeof ITEMS==='undefined'||typeof state==='undefined'||typeof scoreAll!=='function')return;
  if(ITEMS.length!==56 || ITEMS.some(function(it){return !Number.isInteger(state.answers[it.id])||state.answers[it.id]<1||state.answers[it.id]>5;})){
    alert('Please finish all 56 statements before submitting.');return;
  }
  var scores=scoreAll();
  var summary={};
  if(key==='equilibrium'){
    var avg=0;for(var j=0;j<SCALE_KEYS.length;j++) avg+=scores[SCALE_KEYS[j]];
    summary['Emotional intelligence index']=Math.round(avg/SCALE_KEYS.length)+' / 100';
  }
  SCALE_KEYS.forEach(function(k){
    summary[(META[k]&&META[k].name)||k]=scores[k]+' / 100';
  });
  summary['Response candour indicator']=scores.candour+' / 100';
  summary['Attention checks passed']=(scores.acPass||0)+' / '+(scores.acTot||0);
  summary['Response quality check']=scores.qualityOk?'Meets internal checks':'Review response pattern';
  var details=ITEMS.map(function(it,i){return {number:i+1,id:it.id,scale:it.s,question:it.t,answer:state.answers[it.id],reverse_scored:!!it.r};});
  var payload={assessment:key==='meridian'?'MEridian Personality Profile':'EQuilibrium Emotional Intelligence Profile',
    version:PRODUCT.version,
    respondent:{name:identity.name,email:identity.email,organisation:identity.company,role:identity.role,
      age_group:state.info.age||'',gender:state.info.gender||'',life_stage:state.info.stage||'',city:state.info.city||''},
    answers:Object.assign({},state.answers),answer_details:details,
    scores:scores,summary:summary,submitted_at:new Date().toISOString()};
  if(!window.NovarisSubmission||!window.NovarisSubmission.post){alert('The assessment could not connect to the server. Reload and resume your answers.');return;}
  sent=true;
  NovarisSubmission.post({product:key,result_code:key.toUpperCase()+'-'+Date.now(),payload:payload}).then(function(){
    try{localStorage.removeItem(PRODUCT.storeKey)}catch(e){}
  });
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',prefill,{once:true});else prefill();
})();
