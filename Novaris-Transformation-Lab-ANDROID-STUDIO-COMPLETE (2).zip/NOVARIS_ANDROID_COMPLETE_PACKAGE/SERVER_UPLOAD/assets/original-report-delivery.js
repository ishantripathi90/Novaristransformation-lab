/* The *original authored assessment PDF*, not a reconstructed summary, is emailed privately.
 * Never download an original report to a participant's device. All rendering occurs in-browser
 * behind the submission shield; only the short executive summary appears after delivery. */
(function(){
'use strict';
const key=document.body && document.body.dataset && document.body.dataset.novarisTest;
const dual=(key==='meridian'||key==='equilibrium');
const minimumPages=dual?3:8;
const pause=(ms)=>new Promise(r=>setTimeout(r,ms));
function readyLibraries(){return !!(window.jspdf&&typeof window.jspdf.jsPDF==='function');}
async function waitFor(predicate, limit, message){
  const until=Date.now()+limit;
  while(Date.now()<until){try{if(predicate())return;}catch(e){} await pause(130);}
  throw new Error(message);
}
function withCapturedSave(start,label){
  return new Promise(function(resolve,reject){
    if(!readyLibraries()){reject(Error('The original PDF renderer is not loaded. Please reload this assessment.'));return;}
    const original=window.jspdf.jsPDF;
    const originalAlert=window.alert;
    const originalPrint=window.print;
    const originalCanvas=window.html2canvas;
    document.body.classList.add('novaris-pdf-capture');
    /* Offscreen HTML is still rasterised, but the visitor only sees the shield.
       Limit mobile canvas memory across all the original authored report engines. */
    if(typeof originalCanvas==='function') {
      const mobile=/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) ||
        (navigator.deviceMemory && navigator.deviceMemory<=4);
      window.html2canvas=function(node,options){
        const opts=Object.assign({},options||{});
        opts.scale=Math.min(Number(opts.scale)||2,mobile?1.4:1.8);
        return originalCanvas(node,opts);
      };
    }
    let closed=false;
    const timer=setTimeout(()=>done(Error('Full original '+label+' report was not generated in time. Please retry.')),165000);
    function done(err,report){
      if(closed)return;closed=true;clearTimeout(timer);
      window.jspdf.jsPDF=original;
      window.alert=originalAlert;
      window.print=originalPrint;
      if(typeof originalCanvas==='function')window.html2canvas=originalCanvas;
      document.body.classList.remove('novaris-pdf-capture');
      if(err)reject(err);else resolve(report);
    }
    function CapturingPDF(){
      const doc=new original(...arguments);
      doc.save=function(filename){
        try{
          const pages=doc.internal.getNumberOfPages();
          if(pages<minimumPages)throw Error('Incomplete '+label+' report: only '+pages+' pages.');
          const blob=doc.output('blob');
          if(!(blob instanceof Blob)||blob.size<1000||blob.size>17000000)throw Error('Full report has an invalid file size.');
          done(null,{blob:blob,name:label+'.pdf',pages:pages});
          return doc;
        }catch(e){done(e);return doc;}
      };
      return doc;
    }
    CapturingPDF.prototype=original.prototype;
    Object.setPrototypeOf(CapturingPDF,original);
    window.jspdf.jsPDF=CapturingPDF;
    window.alert=function(message){
      done(Error('The original report could not be rendered: '+String(message).slice(0,180)));
    };
    window.print=function(){done(Error('The original PDF renderer requested a browser print fallback. Please retry.'));};
    try{const operation=start();if(operation&&typeof operation.then==='function')operation.catch(done);}catch(e){done(e);}
  });
}
async function buildOriginalReport(product){
  if(product!==key)throw Error('Assessment identity mismatch.');
  await waitFor(readyLibraries,12000,'Original PDF library unavailable.');
  if(dual){
    if(typeof window.renderReport!=='function' || typeof window.downloadPdf!=='function')throw Error('The original assessment report engine is missing.');
    window.renderReport();
    const assessment=await withCapturedSave(()=>window.downloadPdf(1),'Original_Assessment_Report');
    const development=await withCapturedSave(()=>window.downloadPdf(2),'Original_Development_Plan');
    return [assessment,development];
  }
  if(key==='entronovaris')return [await withCapturedSave(()=>window.downloadPdf(),'Complete_Original_Report')];
  if(key==='authorityflow')return [await withCapturedSave(()=>window.downloadPDF(),'Complete_Original_Report')];
  if(key==='growth_readiness')return [await withCapturedSave(()=>window.buildPDFDocument(),'Complete_Original_Report')];
  if(key==='relatiq'){
    await waitFor(()=>document.querySelectorAll('.report-page, .cover').length>=8,16000,'Original RELATIQ report pages were not ready.');
    return [await withCapturedSave(()=>window.downloadPdf(),'Complete_Original_Report')];
  }
  if(key==='team_dynamics'||key==='team_latitude'){
    await waitFor(()=>typeof STATE!=='undefined' && !STATE.busy && document.querySelectorAll('#pagesWrap .rp').length>=8,25000,'Original team report pages are not ready.');
    return [await withCapturedSave(()=>window.downloadPdf(),'Complete_Original_Report')];
  }
  throw Error('No original PDF generator is configured for '+product+'.');
}
window.NovarisOriginalReports={create:buildOriginalReport};
})();
