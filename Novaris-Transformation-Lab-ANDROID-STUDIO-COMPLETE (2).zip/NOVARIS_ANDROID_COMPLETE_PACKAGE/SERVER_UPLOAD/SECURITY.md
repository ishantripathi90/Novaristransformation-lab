# Security and privacy

- No payments, checkout, Client Admin or demo login are provided.
- Result submission requires a valid server session, a matching test, origin checking and a rate-limited attempt. The participant's browser never chooses the destination mailbox: it is fixed to `lead@novaristransformationlab.com`.
- A valid, successfully delivered attempt is marked complete; duplicates are not mailed again. If Titan SMTP does not accept delivery, participants may retry. SMTP acceptance does **not** guarantee inbox placement.
- PDFs are generated only in memory and attached directly to the Novaris email. They are **not** stored in a public web directory or offered to the participant.
- The response-page executive summary is stored in the session only after confirmed SMTP handoff, and protected from indexing/caching.
- Team Latitude is anonymous by design; personal name and email are not collected for its result. Individual anonymous responses are not represented as a team-level rollup.
- Uploaded raw assessment HTML, internal PHP code, `.env` and legacy paid/admin endpoints are blocked with Apache `.htaccess`.
- HTTPS, secure session cookies, output escaping, payload-size limits and email content sanitation apply.
- **Limitations:** Each uploaded assessment uses browser-side scoring. The UI hides raw result/PDF exports, but this is not end-to-end encryption and does not stop a technically knowledgeable visitor inspecting scripts or requests. Strong server-only secrecy would need server-side implementation of each scoring model.
