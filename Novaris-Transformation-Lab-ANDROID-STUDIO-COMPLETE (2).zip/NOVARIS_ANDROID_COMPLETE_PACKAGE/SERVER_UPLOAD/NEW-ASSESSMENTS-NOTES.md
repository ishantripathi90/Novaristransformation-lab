# MEridian and EQuilibrium

The two uploaded original instruments are included unchanged in their 56 statements and native score algorithms.

**Both original report outputs are required:** each generates a 10-page Assessment Report and a separate 4-page Development Plan, sent as **two PDF attachments** to `lead@novaristransformationlab.com`. Participants see only the executive summary on screen. Both PDFs must be delivered before completion is confirmed. The original Novaris triangular mark is the favicon and phone icon.

Their report generation uses locally embedded browser libraries. The PHP wrapper inserts metadata before the **final** `</body>` tag to avoid corrupting the jsPDF library's internal HTML strings. See `CRITICAL-RENDER-FIX.md` and `ORIGINAL-REPORT-DELIVERY.md`.
