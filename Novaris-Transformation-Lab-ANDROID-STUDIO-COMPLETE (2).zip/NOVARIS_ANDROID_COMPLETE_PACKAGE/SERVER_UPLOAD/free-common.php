<?php
declare(strict_types=1);

function novaris_load_env_file(string $path): void {
    if (!is_file($path) || !is_readable($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) return;
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key,$value] = array_map('trim', explode('=', $line, 2));
        if ($key === '' || getenv($key) !== false) continue;
        if (strlen($value)>=2 && (($value[0]==='"' && $value[-1]==='"') || ($value[0]==="'" && $value[-1]==="'"))) $value=substr($value,1,-1);
        putenv($key.'='.$value); $_ENV[$key]=$value; $_SERVER[$key]=$value;
    }
}
novaris_load_env_file(__DIR__.'/.env');

if (session_status() !== PHP_SESSION_ACTIVE) {
    $host=strtolower((string)($_SERVER['HTTP_HOST']??''));
    $local=str_starts_with($host,'localhost')||str_starts_with($host,'127.0.0.1')||str_starts_with($host,'[::1]');
    $https=(!$local)&&((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))==='https'||str_starts_with(strtolower((string)getenv('NOVARIS_BASE_URL')),'https://'));
    ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1'); ini_set('session.cookie_httponly','1');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff'); header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin'); header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

function novaris_h(string $s): string { return htmlspecialchars($s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function novaris_clean(string $s,int $max=190): string { $s=trim(preg_replace('/[\r\n\t]+/u',' ',$s)??''); return function_exists('mb_substr')?mb_substr($s,0,$max,'UTF-8'):substr($s,0,$max); }
function novaris_products(): array { return [
 'team_dynamics'=>['name'=>'Team Dynamics Map','subtitle'=>'Team Work Style Profile','file'=>'team-dynamics-map.php','time'=>'10–12 min'],
 'team_latitude'=>['name'=>'Team Latitude Map','subtitle'=>'Team Psychological Safety Profile','file'=>'team-latitude-map.php','time'=>'10–12 min','anonymous'=>true],
 'authorityflow'=>['name'=>'NOVARIS AuthorityFlow™','subtitle'=>'Organisational Authority & Execution Diagnostic','file'=>'authorityflow-assessment.php','time'=>'15–20 min'],
 'entronovaris'=>['name'=>'Entronovaris™','subtitle'=>'Organisational Vitality & Entropy Assessment','file'=>'entronovaris-assessment.php','time'=>'12–15 min'],
 'growth_readiness'=>['name'=>'Growth-Readiness Matrix™','subtitle'=>'Founder Dependency & Growth Potential Diagnostic','file'=>'growth-readiness-assessment.php','time'=>'12–15 min'],
 'relatiq'=>['name'=>'NOVARIS RELATIQ™','subtitle'=>'Workplace Relationship Dynamics Profile','file'=>'relatiq-assessment.php','time'=>'12–15 min'],
 'meridian'=>['name'=>'MEridian™','subtitle'=>'Personality Profile','file'=>'meridian-assessment.php','time'=>'8–10 min'],
 'equilibrium'=>['name'=>'EQuilibrium™','subtitle'=>'Emotional Intelligence Profile','file'=>'equilibrium-assessment.php','time'=>'8–10 min'],
]; }
function novaris_product(string $key): ?array { $p=novaris_products(); return $p[$key]??null; }
function novaris_results_recipient(): string { return 'lead@novaristransformationlab.com'; }
function novaris_assessment_session(?string $product=null): ?array {
    $s=$_SESSION['free_assessment']??null; if(!is_array($s)) return null;
    if($product!==null && ($s['product']??'')!==$product) return null;
    $started=(int)($s['started_ts']??0); if(!$started || time()-$started>21600) return null;
    return $s;
}
function novaris_same_origin_ok(): bool {
    $origin=trim((string)($_SERVER['HTTP_ORIGIN']??'')); if($origin==='') return true;
    $host=strtolower((string)($_SERVER['HTTP_HOST']??'')); $o=parse_url($origin); if(!is_array($o)||empty($o['host'])) return false;
    $oh=strtolower((string)$o['host']); if(isset($o['port'])) $oh.=':'.(int)$o['port']; return hash_equals($host,$oh);
}
function novaris_new_csrf(): string { return bin2hex(random_bytes(32)); }
