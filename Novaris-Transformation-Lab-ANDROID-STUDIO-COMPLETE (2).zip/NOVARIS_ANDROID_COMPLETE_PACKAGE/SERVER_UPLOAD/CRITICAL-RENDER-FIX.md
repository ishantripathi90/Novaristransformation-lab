# Critical browser rendering fix — 10 October 2026

This full website package supersedes FINAL-8-ASSESSMENTS-TRIANGLE-ICON.

## Why code was appearing as visible text
The MEridian and EQuilibrium tests contain a bundled copy of jsPDF. jsPDF includes HTML document examples as JavaScript strings with literal `<body>` and `</body>` text. The previous PHP wrapper used global `str_replace('</body>', ...)`, inserting real `<script>` tags INSIDE those strings. The browser then closed the bundled script early and displayed the rest of the JavaScript source as page text.

Fix: add `novaris_insert_before_closing_body()` and `novaris_mark_document_body()` in assessment-bootstrap.php. All six dynamically wrapped tests now target the actual document's FINAL opening/closing body tags. Nothing is injected into bundled library strings.

## Image reliability
The homepage's six photographs previously depended on external image URLs for first paint. The site now immediately loads three locally bundled, scale-independent SVG illustrations (workplace-team.svg, workplace-operations.svg and workplace-strategy.svg). Brighter Pexels photographs load opportunistically and are displayed only after success. If a photo server is unavailable, the page still looks complete. Photos require an internet connection; local illustrations do not.

## Preserved
Eight free assessments, original scoring, Novaris triangle favicon, fixed white top navigation, mobile styles, executive summary for participants, private PDF reports mailed to Novaris via the existing Titan integration. No intro video, no checkout and no Client Admin.

## Verification performed
- PHP syntax across every PHP file: PASS
- Node syntax on every inline JavaScript script from the six PHP-rendered HTML test pages: PASS
- Eight authenticated test-start redirects to respective PHP wrappers: PASS
- MEridian/EQuilibrium: no script source in parsed body, correct `data-novaris-test`, single identity injection: PASS
- Home page/assessment listing/PHP pages and all three local image fallbacks: HTTP 200
- No new live SMTP email was sent, and a real mobile browser run was blocked by the test environment, so do a full live assessment test after upload.

## Deployment
Back up your current hosting files and SMTP configuration. Replace the complete site files in public_html, deleting the outdated copy. Upload the CONTENTS of the novaris-transformation-lab directory, rather than nesting the directory inside public_html. After upload hard-reload the website or clear cache on phone. Test MEridian and EQuilibrium using a new assessment attempt. Confirm receipt of the detailed PDF in the Novaris lead inbox.

The .env SMTP configuration included in this ZIP is sensitive. Keep the ZIP private.
