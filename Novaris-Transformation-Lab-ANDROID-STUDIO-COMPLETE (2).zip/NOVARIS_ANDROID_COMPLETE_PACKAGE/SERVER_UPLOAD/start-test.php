<?php
require_once __DIR__.'/free-common.php';
$key=novaris_clean((string)($_GET['test']??$_POST['test']??''),60); $product=novaris_product($key);
if(!$product){http_response_code(404);exit('Assessment not found.');}
$anonymous=!empty($product['anonymous']); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $honeypot=trim((string)($_POST['website']??''));
    if($honeypot!==''){http_response_code(400);exit('Invalid submission.');}
    $name=$anonymous?'Anonymous participant':novaris_clean((string)($_POST['name']??''),120);
    $email=$anonymous?'':trim((string)($_POST['email']??''));
    $company=novaris_clean((string)($_POST['company']??''),160); $role=novaris_clean((string)($_POST['role']??''),120);
    if(!$anonymous && ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL))) $error='Please enter your name and a valid email address.';
    if($error===''){
        session_regenerate_id(true);
        $_SESSION['free_assessment']=['product'=>$key,'name'=>$name,'email'=>$email,'company'=>$company,'role'=>$role,'reference'=>'FREE-'.strtoupper(bin2hex(random_bytes(4))),'attempt_id'=>'free_'.bin2hex(random_bytes(12)),'started_ts'=>time(),'csrf'=>novaris_new_csrf()];
        header('Location: '.$product['file'],true,303); exit;
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title><?=novaris_h($product['name'])?> · Free Assessment</title><link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><link rel="stylesheet" href="assets/free-assessments.css"><link rel="stylesheet" href="assets/free-mobile.css"></head><body><header class="top"><div class="topin"><a href="index.php"><img class="logo" src="assets/novaris-logo-header.png" alt="Novaris Transformation Lab"></a><a class="home" href="assessments.php">← All assessments</a></div></header><main class="wrap"><div class="formbox"><div class="ey">Free assessment · <?=novaris_h($product['time'])?></div><h1><?=novaris_h($product['name'])?></h1><p class="sub"><?=novaris_h($product['subtitle'])?></p><?php if($error!==''):?><div class="err"><?=novaris_h($error)?></div><?php endif;?><?php if($anonymous):?><div class="notice"><b>Anonymous by design.</b> Team Latitude does not collect your name or email here. The result emailed to Novaris contains the assessment scores and an anonymous reference only.</div><?php endif;?><form method="post" autocomplete="on"><input type="hidden" name="test" value="<?=novaris_h($key)?>"><div style="position:absolute;left:-9999px" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div><div class="fields"><?php if(!$anonymous):?><div class="field"><label>Your name *</label><input name="name" required autocomplete="name" value="<?=novaris_h((string)($_POST['name']??''))?>"></div><div class="field"><label>Email *</label><input type="email" name="email" required autocomplete="email" value="<?=novaris_h((string)($_POST['email']??''))?>"></div><div class="field"><label>Organisation</label><input name="company" autocomplete="organization" value="<?=novaris_h((string)($_POST['company']??''))?>"></div><div class="field"><label>Role / designation</label><input name="role" autocomplete="organization-title" value="<?=novaris_h((string)($_POST['role']??''))?>"></div><?php endif;?></div><button class="btn" type="submit">Start <?=novaris_h($product['name'])?> →</button><p class="privacy"><?php if($anonymous):?>After submission, you will see an anonymous executive summary. Your <b>anonymous result</b> will be emailed privately to Novaris.<?php else:?>After completion, you will see your short executive summary. Your full PDF report will be emailed privately to <b><?=novaris_h(novaris_results_recipient())?></b>.<?php endif;?> No payment details are collected.</p></form></div></main></body></html>