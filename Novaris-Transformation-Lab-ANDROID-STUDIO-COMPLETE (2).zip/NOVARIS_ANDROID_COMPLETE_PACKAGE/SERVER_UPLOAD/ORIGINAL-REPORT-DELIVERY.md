# Original full-length report delivery — all eight assessments

## Required delivery split

- **Participant:** gets only the on-screen executive summary on `submission-receipt.php` after successful delivery. No original PDF link/download is provided to them.
- **Novaris:** receives the **original author-designed complete PDF**, with all the pages, visuals, narratives, and recommendations, as the attachment to the email addressed to `lead@novaristransformationlab.com`.
- **MEridian / EQuilibrium:** each produces **two original PDFs** (10-page assessment report and 4-page development plan). Both must attach successfully.
- **Other six:** each produces a single full-length original report using its existing authored report generator.
- Submissions without the original PDF or with fewer than the minimum expected page count are rejected; no summary-only substitutes.

## How it works

The browser renders the original PDF using the assessment's own PDF builder, while a blocking submission shield prevents the participant from viewing the full report. The `jsPDF.save` call is captured **in memory** and no PDF download is initiated. The browser sends the original PDF(s) to `save-result.php` as a multipart file upload. The PHP server validates the PDF signature, completed file trailer, page counts and size, and attaches the unmodified bytes using Titan SMTP.

This does not move the original scoring logic server-side; participants can still inspect browser code with developer tools. This requirement is about normal user-facing access, not cryptographic secrecy of client-side algorithms.

## Hosting requirements

- PHP and HTTPS required. Host's PHP limits should permit at least `upload_max_filesize=24M`, `post_max_size=32M`, `memory_limit=192M`, and a suitable request timeout. `.user.ini` supplies these values on supported hosts; confirm via your hosting PHP selector if ignored.
- Report generation can take longer on phones because it renders up to 12 pages at high resolution. Keep the assessment tab open until the success screen.
- The report PDF may be too large for Titan or the hosting connection; the site will then show Retry rather than a false success. If this persists, review server error logs and Titan's attachment size quota.
- Test a full sample submission for each instrument and check all original pages in the actual `lead@novaristransformationlab.com` inbox. No real message was sent during local development.
- The package includes the existing private `.env` Titan settings; keep the archive private. Back up and fully replace the old website files to avoid stale PHP/JS remaining.

## Tests performed locally

- PHP and JS parsing, entry route rendering for eight instruments.
- MEridian/EQuilibrium capture tested in headless Chromium using a lightweight test canvas in place of full rasterization; both produced PDFs with 10 and 4 pages, matching their original authored structure.
- Multipart upload to PHP with two PDF files accepted through the PDF-validation layer; it reached a deliberately failing local SMTP endpoint. Incomplete two-part uploads are rejected.
- **Not verified:** actual full-resolution rendering in a physical phone browser or live Titan delivery to the real inbox. Perform those before production use.
