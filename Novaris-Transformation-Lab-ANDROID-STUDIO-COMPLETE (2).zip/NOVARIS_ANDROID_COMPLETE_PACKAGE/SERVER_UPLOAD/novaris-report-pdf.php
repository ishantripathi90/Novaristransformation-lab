<?php
/** NOVARIS PDF report renderer - dependency-free, server-side PDF 1.4. */
declare(strict_types=1);

final class NovarisReportPdf {
    private const PW=595.28; private const PH=841.89;
    private array $pages=[]; private string $stream=''; private float $y=0; private int $page=0;
    public function __construct() { $this->newPage(); }
    private function n(float $v): string { return number_format($v,2,'.',''); }
    private function rgb(string $hex): string { $hex=ltrim($hex,'#'); return $this->n(hexdec(substr($hex,0,2))/255).' '.$this->n(hexdec(substr($hex,2,2))/255).' '.$this->n(hexdec(substr($hex,4,2))/255); }
    private function txt(string $text): string {
        $text=preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f]/u',' ', $text)??$text;
        $out=@iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$text);
        $out=$out===false?preg_replace('/[^\x20-\x7E]/','?', $text):$out;
        return str_replace(['\\','(',')'],['\\\\','\\(','\\)'], $out);
    }
    private function block(float $x,float $top,float $w,float $h,string $hex): void { $this->stream.=$this->rgb($hex).' rg '.$this->n($x).' '.$this->n(self::PH-$top-$h).' '.$this->n($w).' '.$this->n($h)." re f\n"; }
    private function line(float $x1,float $top1,float $x2,float $top2,string $hex='#E5EAEE',float $weight=1): void { $this->stream.=$this->rgb($hex).' RG '.$this->n($weight).' w '.$this->n($x1).' '.$this->n(self::PH-$top1).' m '.$this->n($x2).' '.$this->n(self::PH-$top2)." l S\n"; }
    private function text(float $x,float $top,string $text,float $font=10,string $hex='#23344A', bool $bold=false): void {
        $face=$bold?'F2':'F1';$this->stream.='BT /'.$face.' '.$this->n($font).' Tf '.$this->rgb($hex).' rg 1 0 0 1 '.$this->n($x).' '.$this->n(self::PH-$top).' Tm ('.$this->txt($text).") Tj ET\n";
    }
    private function newPage(): void {
        if($this->page){$this->pages[]=$this->stream;}
        $this->stream='';$this->page++;$this->y=129;
        $this->block(0,0,self::PW,91,'#10213D');
        $this->block(0,91,self::PW,5,'#159A91');
        $this->text(45,38,'NOVARIS',21,'#FFFFFF',true);
        $this->text(45,56,'TRANSFORMATION LAB',9,'#BCE9E2',true);
        $this->text(45,77,'CONFIDENTIAL  /  ASSESSMENT REPORT',8,'#C8D7E4');
        $this->line(45,790,550,790,'#DCE5E9');
        $this->text(45,809,'NOVARIS  |  Organisational diagnostics',8,'#7B8A9C');
        $this->text(472,809,'Page '.$this->page,8,'#7B8A9C');
    }
    private function ensure(float $height=35): void { if($this->y+$height>772) $this->newPage(); }
    private function split(string $text,int $max): array {
        $result=[];foreach(explode("\n",str_replace("\r",'',$text)) as $para){
            $para=trim(preg_replace('/\s+/u',' ',$para)??$para);if($para===''){if($result)$result[]='';continue;}
            $line='';foreach(preg_split('/\s+/u',$para)?:[] as $word){
                if($word==='')continue;
                $candidate=$line===''?$word:($line.' '.$word);
                if(mb_strlen_safe($candidate)>$max && $line!==''){$result[]=$line;$line=$word;}else $line=$candidate;
                while(mb_strlen_safe($line)>$max){$result[]=mb_chunk_safe($line,$max);$line=mb_drop_safe($line,$max);}
            }if($line!=='')$result[]=$line;
        }return $result;
    }
    public function heading(string $s): void {$this->ensure(45);$this->text(45,$this->y,$s,16,'#10213D',true);$this->y+=22;$this->line(45,$this->y-8,550,$this->y-8,'#C9E4E0');$this->y+=9;}
    public function smallHeading(string $s): void {$this->ensure(31);$this->text(45,$this->y,$s,11.5,'#11877D',true);$this->y+=22;}
    public function paragraph(string $s): void {foreach($this->split($s,102) as $line){$this->ensure(17);$this->text(45,$this->y,$line,9.5,'#425368');$this->y+=15.3;}$this->y+=11;}
    public function keyValue(string $key,string $value,bool $stripe=false): void {
        $key=trim($key);$value=trim($value);if($value==='')$value='Not provided';
        $lines=$this->split($value,62); if(!$lines)$lines=['-'];if(count($lines)>6)$lines=array_slice($lines,0,6);
        $height=max(28,count($lines)*14+12);$this->ensure($height+2);
        if($stripe)$this->block(45,$this->y-9,505,$height,'#F3F8F7');
        $this->text(53,$this->y+2,mb_chunk_safe($key,38),9,'#10213D',true);
        foreach($lines as $i=>$part)$this->text(262,$this->y+2+$i*14,$part,9,'#26394D');
        $this->y+=$height+3;
    }
    public function meter(string $key,float $pct,string $label=''): void {
        $this->ensure(59);$pct=max(0,min(100,$pct));
        $this->text(45,$this->y,$key,10,'#10213D',true);$this->text(498,$this->y,$this->n($pct).'/100',9,'#567085');
        $this->block(45,$this->y+12,505,9,'#E4EAEE');$this->block(45,$this->y+12,505*$pct/100,9,'#168C82');
        if($label!=='')$this->text(45,$this->y+38,mb_chunk_safe($label,98),8.5,'#677889');
        $this->y+=($label!==''?58:42);
    }
    public function responseQuestion(string $question,string $value): void {
        $lines=array_slice($this->split($question,105),0,5);
        if(!$lines)$lines=['Question'];
        $height=count($lines)*12+24;
        $this->ensure($height+6);
        foreach($lines as $i=>$line)$this->text(46,$this->y+$i*12,$line,8.1,'#10213D',true);
        $this->text(46,$this->y+count($lines)*12+4,'Selected response: '.$value,8.5,'#13877C');
        $this->y+=$height+4;
        $this->line(45,$this->y-9,550,$this->y-9,'#EBEFF1',.5);
    }
    public function responseRow(string $label,string $value): void {
        $value=preg_replace('/\s+/u',' ',trim($value))??$value;$this->ensure(39);
        $this->text(46,$this->y,mb_chunk_safe($label,32),8.2,'#476075',true);
        foreach(array_slice($this->split($value,74),0,3) as $i=>$line){$this->ensure(16);$this->text(222,$this->y+$i*13,$line,8.2,'#26394D');}
        $this->y+=max(23,count($this->split($value,74))*13)+3;
        $this->line(45,$this->y-12,550,$this->y-12,'#EBEFF1',.5);
    }
    public function space(float $n=10): void {$this->y+=$n;}
    public function output(): string {
        $this->pages[]=$this->stream;$n=count($this->pages);$objects=[];
        $objects[1]='<< /Type /Catalog /Pages 2 0 R >>';
        $refs=[];for($i=0;$i<$n;$i++)$refs[]=($i*2+5).' 0 R';
        $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$refs).'] /Count '.$n.' >>';
        $objects[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
        $objects[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';
        foreach($this->pages as $i=>$content){
            $pageId=5+$i*2;$streamId=$pageId+1;
            $objects[$pageId]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '.self::PW.' '.self::PH.'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '.$streamId.' 0 R >>';
            $objects[$streamId]='<< /Length '.strlen($content).' >>' ."\nstream\n".$content."\nendstream";
        }
        ksort($objects);$pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=[0];foreach($objects as $id=>$val){$offsets[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$val."\nendobj\n";}
        $xref=strlen($pdf);$pdf.='xref'."\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";
        for($i=1;$i<=count($objects);$i++)$pdf.=sprintf('%010d 00000 n ',$offsets[$i])."\n";
        $pdf.='trailer << /Size '.(count($objects)+1).' /Root 1 0 R >>' ."\nstartxref\n".$xref."\n%%EOF\n";
        return $pdf;
    }
}
function mb_strlen_safe(string $v): int {return function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v);}
function mb_chunk_safe(string $v,int $n): string {return function_exists('mb_substr')?mb_substr($v,0,$n,'UTF-8'):substr($v,0,$n);}
function mb_drop_safe(string $v,int $n): string {return function_exists('mb_substr')?mb_substr($v,$n,null,'UTF-8'):substr($v,$n);}

/** Summarise only the supplied test engine's actual calculations (no fabricated norms). */
function novaris_report_rows(array $payload): array {
    $rows=[];
    foreach(['summary','dimensions'] as $source){
        $raw=$payload[$source]??[];if(!is_array($raw))continue;
        foreach($raw as $key=>$value){
            if(is_array($value)){$value=($value['score']??$value['name']??null);}
            if(is_bool($value))$value=$value?'Yes':'No';
            if(!is_scalar($value)||trim((string)$value)==='')continue;
            $rows[]= [str_replace(['_','-'],' ',(string)$key),mb_chunk_safe((string)$value,240)];
            if(count($rows)>=24)break 2;
        }
        if($rows)break;
    }
    if(!$rows){foreach(['overall','growthScore','vitality','entropy'] as $k){if(isset($payload[$k])&&is_scalar($payload[$k]))$rows[]=[$k,(string)$payload[$k]];}}
    return $rows;
}
function novaris_report_narrative(string $product): string {
    return match($product){
        'entronovaris'=>'This snapshot explores organisational vitality, entropy and the readiness state derived from the assessment responses. Review the six domains and responses before prioritising change.',
        'authorityflow'=>'This diagnostic explores how outcome clarity, decision rights, autonomy, capability, accountability and escalation interact with execution. The signals are developmental, not a judgement of an individual.',
        'growth_readiness'=>'The matrix locates founder dependency against growth potential. Use the position and dimension scores to frame a leadership conversation, then validate the results against business evidence.',
        'relatiq'=>'This profile describes reported workplace relationship dynamics and interaction preferences. Its dimensions describe patterns rather than fixed labels or clinical traits.',
        'team_dynamics'=>'This profile explores working-style preferences and where different contributions support team effectiveness. Interpretation is strongest when discussed constructively with colleagues.',
        'meridian'=>'This personality profile describes self-reported preferences for openness, conscientiousness, extraversion, agreeableness, emotional stability and relational harmony. It is intended for reflection and development, not selection or diagnosis.',
        'equilibrium'=>'This emotional-intelligence profile describes self-reported skills in self-awareness, self-regulation, inner drive, empathy, relationship management and contextual sensitivity. Results are developmental indicators, not clinical measures.',
        'team_latitude'=>'This response contributes to understanding team climate and psychological safety. One anonymous submission must not be described as a team result; aggregation requires an adequate group.',
        default=>'These are participant-reported diagnostic indications, not independently validated organisational facts.',
    };
}
function novaris_report_answer_pairs(array $payload,string $product): array {
    $out=[];
    if(in_array($product,['meridian','equilibrium'],true) && isset($payload['answer_details']) && is_array($payload['answer_details'])){
        foreach($payload['answer_details'] as $i=>$item){
            if(!is_array($item))continue;
            $q=novaris_clean((string)($item['question']??''),205);
            $number=(int)($item['number']??($i+1));
            $choice=(int)($item['answer']??0);
            if($choice<1||$choice>5)continue;
            $out[]=['Q'.$number.': '.$q,(string)$choice.' / 5'];
            if(count($out)>=80)break;
        }
        return $out;
    }
    $answers=$payload['answers']??($payload['respondent']['answers']??($payload['response']['ans']??($payload['response']??[])));
    if($product==='team_dynamics' && isset($payload['response']['fc']) && is_array($payload['response']['fc'])) {
        foreach($payload['response']['fc'] as $i=>$choice) {
            if(!is_array($choice))continue;
            $out[]=['Work-style prompt '.((int)$i+1), 'Most: '.(string)($choice['m']??'-').'   |   Least: '.(string)($choice['l']??'-')];
        }
        if(isset($payload['response']['dv']) && is_array($payload['response']['dv']))
            foreach($payload['response']['dv'] as $i=>$v)if(is_scalar($v))$out[]=['Work-style dial '.((int)$i+1),(string)$v];
        if(isset($payload['response']['role']))$out[]=['Team role',(string)$payload['response']['role']];
        return $out;
    }
    if(is_array($answers)){
        foreach($answers as $key=>$value){
            if(is_array($value))$value=json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if(!is_scalar($value))continue;
            $label=is_int($key)||ctype_digit((string)$key)?'Question '.((int)$key+($product==='entronovaris'?0:1)):(string)$key;
            $out[]=[$label,mb_chunk_safe((string)$value,260)];
            if(count($out)>=150)break;
        }
    }
    if(!$out && isset($payload['response']) && is_array($payload['response'])){
        foreach($payload['response'] as $k=>$v)if(is_scalar($v))$out[]=[(string)$k,(string)$v];
    }
    return $out;
}
function novaris_make_report_pdf(string $productKey,array $product,array $session,array $payload,array $rows,string $reference,string $submitted): string {
    $pdf=new NovarisReportPdf();$name=!empty($product['anonymous'])?'Anonymous participant':(string)($session['name']??'');
    $pdf->heading((string)$product['name']);
    $pdf->paragraph((string)$product['subtitle']);
    $pdf->smallHeading('REPORT DETAILS');
    $pdf->keyValue('Reference',$reference,true);$pdf->keyValue('Submitted',$submitted);
    $pdf->keyValue('Participant',$name,true);
    if(empty($product['anonymous']))$pdf->keyValue('Contact',(string)($session['email']??''));
    $pdf->keyValue('Organisation',(string)($session['company']??''),true);
    $pdf->keyValue('Role',(string)($session['role']??''));
    $pdf->space(16);$pdf->heading('Executive overview');
    $pdf->paragraph(novaris_report_narrative($productKey));
    $pdf->paragraph('The following indicators are drawn from the completed assessment, as reported by the respondent. Read them alongside the item-level responses and any relevant workplace evidence.');
    $pdf->heading('Assessment indicators');
    if(!$rows)$pdf->paragraph('No scalar summary was supplied by the scoring engine. See recorded responses below.');
    foreach($rows as [$key,$value]){
        if(str_contains((string)$value,'/100') && preg_match('/^\s*(\d{1,3})(?:\.\d+)?\s*\/\s*100/',(string)$value,$m)&&is_numeric($m[1])&&$m[1]<=100){$pdf->meter((string)$key,(float)$m[1],(string)$value);}
        else $pdf->keyValue((string)$key,(string)$value);
    }
    if(isset($payload['scores']['domains']) && is_array($payload['scores']['domains'])){
        $pdf->heading('Domain detail');foreach($payload['scores']['domains'] as $domain){
            if(!is_array($domain))continue;$label=(string)($domain['D']['name']??$domain['name']??'Domain');
            $score=$domain['entropy']??$domain['score']??null;if(is_numeric($score))$pdf->meter($label,(float)$score,'As calculated by the assessment engine');
        }
    }
    $pdf->heading('Response record');
    $pairs=novaris_report_answer_pairs($payload,$productKey);
    if(!$pairs)$pdf->paragraph('No itemised response array was provided. The recorded summary above is the information received.');
    foreach($pairs as [$key,$val]){
        if(in_array($productKey,['meridian','equilibrium'],true))$pdf->responseQuestion((string)$key,(string)$val);
        else $pdf->responseRow((string)$key,(string)$val);
    }
    $pdf->space(10);$pdf->heading('Interpretation and next steps');
    $pdf->paragraph('1. Discuss the most relevant score patterns with the appropriate team or participant.');
    $pdf->paragraph('2. Check perceived issues against interviews, documented workflows and operational evidence.');
    $pdf->paragraph('3. Agree practical actions and review progress at a future date.');
    $pdf->paragraph('Confidential Novaris assessment report. These self-reported insights are not certified psychometric norms or sufficient evidence for employment decisions.');
    return $pdf->output();
}
