<?php
require_once __DIR__.'/free-common.php';
if (!headers_sent()) { header('X-Robots-Tag: noindex, nofollow', true); header('Cache-Control: no-store, private'); }

function novaris_assessment_page_context(string $productKey): array {
    $product=novaris_product($productKey); if(!$product){http_response_code(404);exit('Unknown assessment.');}
    $s=novaris_assessment_session($productKey);
    if(!$s){ header('Location: start-test.php?test='.rawurlencode($productKey),true,303); exit; }
    if(!empty($s['completed_ts'])) { header('Location: submission-receipt.php',true,303); exit; }
    return [
      'mode'=>'employee','product_key'=>$productKey,'product'=>$product,
      'company'=>['id'=>'free','name'=>(string)($s['company']??'')],
      'employee'=>['name'=>(string)($s['name']??''),'email'=>(string)($s['email']??''),'department'=>(string)($s['role']??''),'external_id'=>(string)($s['reference']??'')],
      'assignment'=>['id'=>(string)($s['attempt_id']??''),'status'=>'active','result_code'=>null,'result'=>null]
    ];
}
function novaris_public_assessment_context(array $ctx): array {
    return ['mode'=>'employee','product_key'=>$ctx['product_key'],'company'=>$ctx['company'],'employee'=>$ctx['employee'],'assignment'=>$ctx['assignment']];
}
function novaris_portal_css(): string { return '<style>body{font-family:Arial,sans-serif;background:#f7f6f2;color:#111858}.portal-main{max-width:800px;margin:50px auto;padding:20px}.portal-card{background:#fff;padding:30px;border-radius:18px;border:1px solid #ddd}.portal-btn{display:inline-block;padding:12px 18px;background:#111858;color:#fff;text-decoration:none;border-radius:10px}</style>'; }


/** Append markup before the DOCUMENT'S closing tag, never inside an inline JS string.
 * Bundled jsPDF contains literal HTML strings like "</body>" and "<body>".
 * Global replacements would insert <script> markup inside that library and break the page.
 */
function novaris_insert_before_closing_body(string $html, string $markup): string {
    $pos = strripos($html, '</body>');
    if ($pos === false) { throw new RuntimeException('Assessment document body closing tag missing.'); }
    return substr_replace($html, $markup, $pos, 0);
}
function novaris_mark_document_body(string $html, string $product): string {
    if (!preg_match_all('/<body\b[^>]*>/i', $html, $matches, PREG_OFFSET_CAPTURE) || !$matches[0]) {
        throw new RuntimeException('Assessment document body opening tag missing.');
    }
    $last = end($matches[0]);
    $start = $last[1];
    $tag = $last[0];
    $tag = preg_replace('/^<body\b/i', '<body data-novaris-test="'.htmlspecialchars($product, ENT_QUOTES, 'UTF-8').'"', $tag, 1);
    return substr_replace($html, $tag, $start, strlen($last[0]));
}
