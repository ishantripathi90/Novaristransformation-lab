<?php
/** Save a free assessment only after its full PDF was accepted by Titan SMTP. */
declare(strict_types=1);
require_once __DIR__.'/free-common.php';
require_once __DIR__.'/titan-smtp.php';
require_once __DIR__.'/novaris-report-pdf.php'; // score summaries only; original PDF bytes arrive as multipart uploads
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: private, no-store');
function novaris_fail(string $reason,int $status=400): never { http_response_code($status);echo json_encode(['ok'=>false,'error'=>$reason]);exit; }
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')novaris_fail('method_not_allowed',405);
if(!novaris_same_origin_ok())novaris_fail('origin_rejected',403);
$session=novaris_assessment_session();if(!$session)novaris_fail('session_expired',401);
if(empty($_POST['data']) || !is_string($_POST['data']) || strlen($_POST['data'])>900000)novaris_fail('invalid_payload',413);
$input=json_decode($_POST['data'],true);if(!is_array($input))novaris_fail('invalid_json');
if(empty($_FILES['reports']) || !is_array($_FILES['reports'])) novaris_fail('original_pdf_missing',422);
$key=novaris_clean((string)($input['product']??''),64);
if($key===''||$key!==($session['product']??''))novaris_fail('product_mismatch',403);
$product=novaris_product($key);if(!$product)novaris_fail('unknown_product',404);
$payload=$input['payload']??null;if(!is_array($payload))novaris_fail('missing_result');
if(in_array($key,['meridian','equilibrium'],true)){
    $answers=$payload['answers']??null; $details=$payload['answer_details']??null;
    if(!is_array($answers)||count($answers)!==56||!is_array($details)||count($details)!==56)novaris_fail('incomplete_assessment');
    foreach($answers as $v){if(!is_int($v)||$v<1||$v>5)novaris_fail('invalid_answer');}
    if(!is_array($payload['summary']??null))novaris_fail('missing_scores');
}

$completed=$_SESSION['free_result_sent']??[];if(!is_array($completed))$completed=[];
$dedupe=$key.'|'.(string)($session['attempt_id']??'');
if(isset($completed[$dedupe])||!empty($session['completed_ts'])){
    echo json_encode(['ok'=>true,'emailed'=>true,'duplicate'=>true]);exit;
}
$times=$_SESSION['free_submit_times']??[];if(!is_array($times))$times=[];
$times=array_values(array_filter($times,static fn($t)=>is_int($t)&&$t>time()-3600));
if(count($times)>=20)novaris_fail('rate_limited',429);

$anonymous=!empty($product['anonymous']);
$name=$anonymous?'Anonymous respondent':novaris_clean((string)($session['name']??''),120);
$email=$anonymous?'':trim((string)($session['email']??''));
$company=novaris_clean((string)($session['company']??''),160);
$ref=novaris_clean((string)($session['reference']??''),80);
$submitted=gmdate('d M Y, H:i T');
$rows=novaris_report_rows($payload);
$summary=[];
foreach(array_slice($rows,0,9) as [$label,$value]){
    $summary[]=['label'=>novaris_clean((string)$label,100),'value'=>novaris_clean((string)$value,230)];
}
if(!$summary)$summary[]=['label'=>'Assessment','value'=>'Completed'];

// Never substitute a reconstructed PDF. Reject incomplete/missing uploads.
$upload=$_FILES['reports'];$files=[];
foreach(['name','tmp_name','size','error'] as $field){ if(!isset($upload[$field])||!is_array($upload[$field]))novaris_fail('invalid_pdf_upload',422); }
$expected=in_array($key,['meridian','equilibrium'],true)?2:1;
if(count($upload['name'])!==$expected||count($upload['tmp_name'])!==$expected)novaris_fail('original_report_parts_missing',422);
$totalBytes=0;$attachments=[];$nativePages=[];
foreach(range(0,$expected-1) as $idx){
    if(($upload['error'][$idx]??-1)!==UPLOAD_ERR_OK)novaris_fail('pdf_upload_failed_check_host_limits',413);
    $tmp=$upload['tmp_name'][$idx]??''; $size=(int)($upload['size'][$idx]??0);
    if(!is_string($tmp)||!is_uploaded_file($tmp)||$size<1100||$size>17000000)novaris_fail('invalid_original_pdf',422);
    $totalBytes+=$size;if($totalBytes>17000000)novaris_fail('pdfs_exceed_email_limit',413);
    $bytes=file_get_contents($tmp);if($bytes===false||strlen($bytes)!==$size)novaris_fail('pdf_read_failed',500);
    if(!str_starts_with($bytes,'%PDF-')||!str_contains(substr($bytes,-2048),'%%EOF'))novaris_fail('invalid_pdf_document',422);
    $pages=preg_match_all('~/Type\s*/Page\b~',$bytes);
    $minPages=$expected===2?3:8;
    if($pages<$minPages)novaris_fail('incomplete_original_report',422);
    $nativePages[]=$pages;
    $part=$expected===2?($idx===0?'Original_Assessment_Report':'Original_Development_Plan'):'Complete_Original_Report';
    $filename='Novaris_'.preg_replace('/[^A-Za-z0-9_-]/','_', $key).'_'.$ref.'_'.$part.'.pdf';
    $attachments[]=['filename'=>$filename,'content'=>$bytes,'mime'=>'application/pdf'];
}

$h=static fn(string $s):string=>htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
$preview='';$previewText='';
foreach(array_slice($summary,0,8) as $item){
    $preview.='<tr><td style="padding:9px 11px;border-bottom:1px solid #e5ecef;font-weight:700">'.$h($item['label']).'</td><td style="padding:9px 11px;border-bottom:1px solid #e5ecef">'.$h($item['value']).'</td></tr>';
    $previewText.=$item['label'].': '.$item['value']."\n";
}
$subject='[PDF Report] '.$product['name'].' - '.($anonymous?$ref:($name?:$ref));
$html='<!doctype html><html><body style="margin:0;background:#f4f8f8;font-family:Arial,sans-serif;color:#26394d"><div style="max-width:650px;margin:28px auto;background:#fff;border:1px solid #e0e8ed"><div style="background:#10213d;color:#fff;padding:26px"><div style="font-size:12px;letter-spacing:2px;color:#9ee7df">NOVARIS TRANSFORMATION LAB</div><h1 style="font-size:24px;margin:12px 0 0">New completed assessment</h1></div><div style="padding:26px"><p><b>Assessment:</b> '.$h($product['name']).'<br><b>Respondent:</b> '.$h($name).'<br><b>Organisation:</b> '.$h($company?:'Not supplied').'<br><b>Reference:</b> '.$h($ref).'<br><b>Submitted:</b> '.$h($submitted).'</p>'.($email?'<p><b>Participant email:</b> '.$h($email).'</p>':'').'<h2 style="font-size:18px;color:#10213d">Key indicators</h2><table style="border-collapse:collapse;width:100%;font-size:13px">'.$preview.'</table><p style="padding:16px;background:#e9f6f3;border-left:4px solid #149c96;margin-top:24px"><strong>The original full-length assessment report is attached as a PDF.</strong><br>These are the original authored report pages, including their detailed interpretation, visuals and recommendations. The participant only sees the executive summary.</p><p style="font-size:12px;color:#718294">This email was generated by the Novaris free assessment site.</p></div></div></body></html>';
$text="NOVARIS - COMPLETED ASSESSMENT\nAssessment: {$product['name']}\nRespondent: $name\nOrganisation: $company\nReference: $ref\nSubmitted: $submitted\n".($email?"Email: $email\n":'')."\nKEY INDICATORS\n".$previewText."\nFULL ORIGINAL REPORT: See attached PDF(s).\n";
$config=require __DIR__.'/smtp-config.php';
$sent=false;
for($try=0;$try<2;$try++){
    try{
        (new TitanSmtpClient($config))->send(novaris_results_recipient(),'Novaris Reports',$subject,$html,$text,$email?:null,$name?:null,$attachments);
        $sent=true;break;
    }catch(Throwable $err){error_log('Novaris PDF email failed (attempt '.($try+1).'): '.$err->getMessage());if($try===0)usleep(250000);}
}
if(!$sent)novaris_fail('email_failed_retry',502);

$times[]=time();$_SESSION['free_submit_times']=$times;
$completed[$dedupe]=time();$_SESSION['free_result_sent']=$completed;
$_SESSION['free_assessment']['completed_ts']=time();
$_SESSION['free_assessment']['executive_summary']=[
    'title'=>$product['name'],'reference'=>$ref,'overview'=>novaris_report_narrative($key),
    'indicators'=>$summary,
    'anonymous'=>$anonymous,
];
// Do not store raw responses or full PDF in server sessions.
echo json_encode(['ok'=>true,'emailed'=>true,'pdf_attached'=>true,'original'=>true,'attachment_pages'=>$nativePages]);
