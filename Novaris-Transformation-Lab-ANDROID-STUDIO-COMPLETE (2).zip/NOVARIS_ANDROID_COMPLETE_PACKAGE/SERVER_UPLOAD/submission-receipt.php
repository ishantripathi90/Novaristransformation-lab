<?php
declare(strict_types=1);
require_once __DIR__.'/free-common.php';
$s=novaris_assessment_session();
if(!$s||empty($s['completed_ts'])){header('Location: assessments.php',true,303);exit;}
$p=novaris_product((string)($s['product']??''));
$r=$s['executive_summary']??[];
if(!is_array($r))$r=[];
$indicators=is_array($r['indicators']??null)?$r['indicators']:[];
header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>Your executive summary | Novaris</title><link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><link rel="stylesheet" href="assets/free-assessments.css"><link rel="stylesheet" href="assets/free-mobile.css"><style>
body{background:#f4f7f8;color:#213245}.top{position:sticky!important;top:0!important;z-index:200!important;box-shadow:0 4px 22px rgba(15,30,52,.06)}
.result-wrap{max-width:900px;margin:40px auto 80px;padding:0 20px}.result{background:#fff;border:1px solid #dce7e9;border-radius:17px;box-shadow:0 15px 50px rgba(16,33,61,.06);overflow:hidden}
.result-head{padding:35px clamp(24px,5vw,48px);background:linear-gradient(115deg,#ebf7f2 0%,#f6fbfd 90%)}.result-head .ey{color:#12877e}.result-head h1{font:600 clamp(28px,3.7vw,41px)/1.14 Georgia,serif;color:#10213d;margin:12px 0}.result-head p{font-size:14px;line-height:1.65;color:#506677;max-width:680px}.result-content{padding:30px clamp(24px,5vw,48px) 45px}.result-content h2{font:600 23px Georgia,serif;color:#10213d;margin:24px 0 12px}.intro-notice{font-size:13px;line-height:1.65;background:#e7f5f1;padding:14px 16px;border-radius:8px;border-left:4px solid #168d80}.summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.summary-item{background:#f8fbfb;border:1px solid #e0e8ec;border-radius:11px;padding:16px}.summary-item small{font-size:11px;letter-spacing:.06em;text-transform:uppercase;font-weight:750;color:#586d7b}.summary-item b{display:block;font-size:17px;color:#10213d;margin-top:8px;line-height:1.4;overflow-wrap:anywhere}.result-content p{font-size:14px;line-height:1.75;color:#5c6b7b}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:28px}.actions a{padding:12px 18px;border-radius:9px;text-decoration:none;font-weight:800;font-size:13px;background:#10213d;color:#fff}.actions a.secondary{background:#fff;border:1px solid #cbdadd;color:#10213d}
@media(max-width:620px){.summary-grid{grid-template-columns:1fr}.result-wrap{margin-top:22px}}
</style></head><body><header class="top"><div class="topin"><a href="index.php"><img class="logo" src="assets/novaris-logo-header.png" alt="Novaris Transformation Lab"></a><a class="home" href="assessments.php">All assessments</a></div></header>
<main class="result-wrap"><section class="result"><div class="result-head"><div class="ey">Assessment completed ✓</div><h1>Your executive summary</h1><p><?=novaris_h((string)($p['name']??'Novaris assessment'))?> · <?=novaris_h((string)($r['reference']??$s['reference']??''))?></p><p>Your assessment has been securely submitted. The <strong>full detailed PDF report</strong> was sent privately to the Novaris team.</p></div>
<div class="result-content"><div class="intro-notice">This is your short on-screen summary only. The complete report, item-level answers and detailed analysis are sent to Novaris. No report download is offered here.</div>
<h2>What this assessment examines</h2><p><?=novaris_h((string)($r['overview']??'Your responses provide a directional snapshot of organisational conditions.'))?></p>
<h2>Key findings from your responses</h2><div class="summary-grid">
<?php foreach($indicators as $entry): if(!is_array($entry))continue; ?>
<div class="summary-item"><small><?=novaris_h((string)($entry['label']??'Indicator'))?></small><b><?=novaris_h((string)($entry['value']??'—'))?></b></div>
<?php endforeach; ?>
</div>
<?php if(!empty($r['anonymous'])): ?><p><strong>Privacy note:</strong> Your Team Latitude response remains anonymous. This summary describes one response, not an aggregated team assessment.</p><?php endif;?>
<h2>Next step</h2><p>Use these indicators as starting points for reflection, not as a final diagnosis. The Novaris team can review the full report and discuss what the findings mean in context.</p><div class="actions"><a href="assessments.php">Explore other assessments →</a><a class="secondary" href="index.php">Back to website</a></div></div></section></main></body></html>
