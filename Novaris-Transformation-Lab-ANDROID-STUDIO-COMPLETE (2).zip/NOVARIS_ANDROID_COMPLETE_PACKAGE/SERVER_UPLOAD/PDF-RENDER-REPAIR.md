# Original PDF render and private email repair (13 October 2026)

## Symptom fixed
Entronovaris could show: "The PDF could not be generated here. Your browser's print dialog will open instead: choose Save as PDF." This should never happen to a participant.

## Changes
- Removed Entronovaris print-dialog fallback and the user-facing PDF alerts. Exceptions are now caught by the shared private-delivery overlay, with a Retry option. No submission success is shown without delivery acknowledgement.
- Fixed `#pdfRender {display:none!important}` conflict; it is rendered offscreen under the blocking confirmation overlay.
- Preserved all 12 original Entronovaris PDF pages. Phone-size rendering uses lower canvas memory (1.35x) and releases each rendered canvas after insertion.
- Applied a capture-only CSS override for the hidden report containers across AuthorityFlow, Growth-Readiness, RELATIQ, Team Dynamics, Team Latitude, MEridian and EQuilibrium. The full authored PDF remains unavailable to participants in the normal UI.
- During private PDF capture, memory-intensive html2canvas scales are capped to 1.4 on phones/low-memory devices and 1.8 on larger devices, without changing the authored page content.
- If an original report engine attempts to show a browser Print/Save dialog, the capture aborts to Retry instead.
- Versioned CSS and JavaScript asset references so browsers don't keep broken cached files.

## Testing
- Direct Playwright/Chromium mobile-sized in-memory test: Entronovaris generated an original 12-page PDF (1.9MB), no JavaScript errors or print dialogs.
- Same test: MEridian generated 10-page report + 4-page development plan; EQuilibrium generated 10-page report + 4-page development plan, each without print dialogs.
- QA used sample responses only. It did not perform a real email delivery or represent physical Android/iPhone testing.
- Remaining five original builders had their offscreen visibility conflict repaired, but full in-browser attachment capture was not retested on physical phones. Check sample submissions on deployed hosting before relying on them.

## Requirements
PHP with secure Titan SMTP configuration and adequate upload size, HTTPS, Chrome / Safari recent browser. See `ORIGINAL-REPORT-DELIVERY.md` and `DEPLOYMENT.md`. Ensure old files are completely replaced and clear the browser cache or test Incognito. Back up your .env before deploying; the package contains private SMTP configuration and should not be shared publicly.
