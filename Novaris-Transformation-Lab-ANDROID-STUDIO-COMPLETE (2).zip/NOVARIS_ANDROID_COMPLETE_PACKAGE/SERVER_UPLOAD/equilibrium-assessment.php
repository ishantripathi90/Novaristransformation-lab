<?php
require_once __DIR__ . '/assessment-bootstrap.php';
$ctx=novaris_assessment_page_context('equilibrium');
$html=file_get_contents(__DIR__ . '/assessments/equilibrium/test.html');
if($html===false){http_response_code(500);exit('Assessment file unavailable.');}
$session=novaris_assessment_session('equilibrium');
if(!$session){header('Location: start-test.php?test=equilibrium',true,303);exit;}
$info=[
  'name'=>(string)($session['name']??''),
  'email'=>(string)($session['email']??''),
  'company'=>(string)($session['company']??''),
  'role'=>(string)($session['role']??''),
  'attempt'=>(string)($session['attempt_id']??''),
];
$infoJson=json_encode($info,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE);
// Per-session draft key avoids one participant seeing another's answers on a shared device.
$html=str_replace('__STORE_KEY__','equilibrium_free_'.preg_replace('/[^a-zA-Z0-9_]/','',(string)$session['attempt_id']),$html);
$html=str_replace('</head>', '<meta name="robots" content="noindex,nofollow"><meta http-equiv="Cache-Control" content="no-store"><link rel="icon" href="favicon.ico?v=20261010triangletriangle" sizes="any"><link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png"><link rel="apple-touch-icon" href="assets/apple-touch-icon.png"><link rel="stylesheet" href="assets/unified-assessments.css?v=20261013reportfix2"><link rel="stylesheet" href="assets/test-mobile.css"><link rel="stylesheet" href="assets/new-personal-profiles.css?v=20261013reportfix2"><script src="assets/unified-assessments.js?v=20261013reportfix2" defer></script><script src="assets/original-report-delivery.js?v=20261013reportfix2" defer></script></head>', $html);
$html=novaris_mark_document_body($html, 'equilibrium');
$bridge='<script>window.NOVARIS_PROFILE_IDENTITY='.$infoJson.';</script><script src="assets/new-personal-profiles.js" defer></script>';
$html=novaris_insert_before_closing_body($html, $bridge);
// The authored tests contain only browser-side results which the participant never sees.
echo $html;
