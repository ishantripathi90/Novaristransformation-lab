<?php
require_once __DIR__ . '/assessment-bootstrap.php';
$ctx = novaris_assessment_page_context('entronovaris');

if (($ctx['mode'] ?? '') === 'employee_completed') {
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Entronovaris™ submitted | Novaris Transformation Lab</title><?= novaris_portal_css() ?></head><body class="portal-body"><main class="portal-main"><div class="portal-shell"><div class="portal-card accent" style="max-width:760px;margin:40px auto;"><div class="portal-kicker">Assessment submitted</div><h1 class="portal-title">Entronovaris™ has already been completed.</h1><p class="portal-sub">Thank you, <?= novaris_h((string)($ctx['employee']['name'] ?? '')) ?>. Your completed assessment has been sent privately to the Novaris team.</p><p><a class="portal-btn" href="index.php">Close assessment →</a></p></div></div></main></body></html><?php
    exit;
}

$html = file_get_contents(__DIR__ . '/assessments/entronovaris/test.html');
if ($html === false) {
    http_response_code(500);
    exit('Assessment source file could not be loaded.');
}

$assignment = is_array($ctx['assignment'] ?? null) ? $ctx['assignment'] : [];
$storedResult = is_array($assignment['result'] ?? null) ? $assignment['result'] : [];
$values = [
    '__MODE__' => json_encode((string)($ctx['mode'] ?? 'employee')),
    '__EMPLOYEE_NAME__' => json_encode((string)($ctx['employee']['name'] ?? '')),
    '__EMPLOYEE_EMAIL__' => json_encode((string)($ctx['employee']['email'] ?? '')),
    '__COMPANY_NAME__' => json_encode((string)($ctx['company']['name'] ?? '')),
    '__ASSIGNMENT_ID__' => json_encode((string)($assignment['id'] ?? '')),
    '__STORED_RESULT__' => json_encode($storedResult, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
];

$portalJs = <<<'JS'
<script>
window.NOVARIS_PLATFORM_CONTEXT = {
  mode: __MODE__,
  employeeName: __EMPLOYEE_NAME__,
  employeeEmail: __EMPLOYEE_EMAIL__,
  companyName: __COMPANY_NAME__,
  assignmentId: __ASSIGNMENT_ID__,
  storedResult: __STORED_RESULT__
};
(function(){
  var ctx = window.NOVARIS_PLATFORM_CONTEXT;
  var saveState = {saving:false, saved:false, promise:null};

  /* Keep browser autosave isolated to this private assignment. */
  if (typeof STORE_KEY !== 'undefined') {
    STORE_KEY = 'entronovaris_v2_' + (ctx.assignmentId || 'review');
  }

  /* Client-admin review: restore the exact submitted answers so the original
     assessment can rebuild its complete scored screen and 12-page PDF. */
  if (ctx.mode === 'review' && ctx.storedResult && ctx.storedResult.respondent) {
    RESP = ctx.storedResult.respondent;
    if (!RESP.answers) RESP.answers = {};
  } else if (ctx.mode === 'employee') {
    RESP.name = ctx.employeeName || RESP.name || '';
    RESP.email = ctx.employeeEmail || RESP.email || '';
    RESP.org = ctx.companyName || RESP.org || '';
  }

  function resultSummary(scores){
    if (!scores) return {};
    var q = (typeof QUADS !== 'undefined' && QUADS[scores.quad]) ? QUADS[scores.quad] : null;
    return {
      'Vitality': scores.vitality,
      'Entropy': scores.entropy,
      'Overall entropy index': scores.overall,
      'Readiness state': q ? q.label : (scores.quad || '')
    };
  }

  function saveAssessment(){
    if (ctx.mode !== 'employee') return Promise.resolve(true);
    if (saveState.promise) return saveState.promise;
    var scores=(typeof SCORES !== 'undefined' && SCORES)?SCORES:computeScores();
    var payload={assessment:'Entronovaris™',respondent:RESP,scores:scores,summary:resultSummary(scores),submitted_at:new Date().toISOString()};
    saveState.promise=NovarisSubmission.post({product:'entronovaris',result_code:'ENTRO-'+Date.now().toString().slice(-8),payload:payload});
    return saveState.promise;
  }

  /* The uploaded assessment enters results through renderResults(). Save once
     at that exact point, while leaving its own PDF generator completely intact. */
  if (typeof window.renderResults === 'function') {
    var originalRenderResults = window.renderResults;
    window.renderResults = function(){
      if (ctx.mode === 'employee') {
        SCORES=computeScores();
        saveAssessment();
      } else {
        originalRenderResults.apply(this, arguments);
      }
    };
  }

  document.addEventListener('DOMContentLoaded', function(){
    if (ctx.mode === 'employee') {
      var name = document.getElementById('fName');
      var email = document.getElementById('fEmail');
      var org = document.getElementById('fOrg');
      if (name && ctx.employeeName) { name.value = ctx.employeeName; name.readOnly = true; }
      if (email && ctx.employeeEmail) { email.value = ctx.employeeEmail; email.readOnly = true; }
      if (org && ctx.companyName) { org.value = ctx.companyName; org.readOnly = true; }
      /* Sync the prefilled values back into the assessment state after its own init. */
      if (typeof readForm === 'function') readForm();
      if (typeof save === 'function') save();
    }

    if (ctx.mode === 'review') {
      var edit = document.getElementById('btnEdit');
      var fresh = document.getElementById('btnNew');
      if (edit) edit.style.display = 'none';
      if (fresh) fresh.style.display = 'none';
      var note = document.querySelector('.return');
      if (note) note.innerHTML = '<b>Stored-result review.</b> The full PDF can be generated from this screen.';
      if (typeof go === 'function') go(7);
    }
  });
})();
</script>
JS;

$portalJs = str_replace(array_keys($values), array_values($values), $portalJs);
$html = novaris_insert_before_closing_body($html, $portalJs . "\n");
$html = str_replace('</head>', '<link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><link rel="stylesheet" href="assets/unified-assessments.css?v=20261013reportfix2"><link rel="stylesheet" href="assets/test-mobile.css"><script src="assets/unified-assessments.js?v=20261013reportfix2" defer></script><script src="assets/original-report-delivery.js?v=20261013reportfix2" defer></script></head>', $html);
$html = novaris_mark_document_body($html, 'entronovaris');
echo $html;
