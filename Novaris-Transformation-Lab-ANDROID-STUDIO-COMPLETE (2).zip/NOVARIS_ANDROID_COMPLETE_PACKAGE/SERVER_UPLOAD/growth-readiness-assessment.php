<?php
require_once __DIR__ . '/assessment-bootstrap.php';
$ctx = novaris_assessment_page_context('growth_readiness');
if (($ctx['mode'] ?? '') === 'employee_completed') {
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Growth Readiness submitted | Novaris Transformation Lab</title><?= novaris_portal_css() ?></head><body class="portal-body"><main class="portal-main"><div class="portal-shell"><div class="portal-card accent" style="max-width:760px;margin:40px auto;"><div class="portal-kicker">Assessment submitted</div><h1 class="portal-title">Growth-Readiness Matrix™ has already been completed.</h1><p class="portal-sub">Thank you, <?= novaris_h((string)($ctx['employee']['name'] ?? '')) ?>. Your completed result has been sent securely to Novaris.</p><p><a class="portal-btn" href="index.php">Close assessment →</a></p></div></div></main></body></html><?php
    exit;
}

$html = file_get_contents(__DIR__ . '/assessments/growth-readiness/test.html');
if ($html === false) {
    http_response_code(500);
    exit('Assessment source file could not be loaded.');
}
$assignment = is_array($ctx['assignment'] ?? null) ? $ctx['assignment'] : [];
$storedResult = is_array($assignment['result'] ?? null) ? $assignment['result'] : [];
$values = [
    '__MODE__' => json_encode((string)($ctx['mode'] ?? 'employee')),
    '__EMPLOYEE_NAME__' => json_encode((string)($ctx['employee']['name'] ?? '')),
    '__EMPLOYEE_EMAIL__' => json_encode((string)($ctx['employee']['email'] ?? '')),
    '__COMPANY_NAME__' => json_encode((string)($ctx['company']['name'] ?? '')),
    '__EXTERNAL_ID__' => json_encode((string)($ctx['employee']['external_id'] ?? '')),
    '__DEPARTMENT__' => json_encode((string)($ctx['employee']['department'] ?? '')),
    '__STORED_RESULT__' => json_encode($storedResult, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
];
$overrideJs = <<<'JS'
<script>
window.NOVARIS_PLATFORM_CONTEXT = {
  product: 'growth_readiness',
  mode: __MODE__,
  employeeName: __EMPLOYEE_NAME__,
  employeeEmail: __EMPLOYEE_EMAIL__,
  companyName: __COMPANY_NAME__,
  externalId: __EXTERNAL_ID__,
  department: __DEPARTMENT__,
  storedResult: __STORED_RESULT__
};
(function(){
  var ctx = window.NOVARIS_PLATFORM_CONTEXT;
  var saveState = {saving:false, saved:false, resultCode:''};

  function prefill(){
    if(ctx.mode !== 'employee') return;
    var map = {
      'inp-name': ctx.employeeName,
      'inp-email': ctx.employeeEmail,
      'inp-business': ctx.companyName,
      'inp-role': ctx.department || ctx.externalId
    };
    Object.keys(map).forEach(function(id){
      var el = document.getElementById(id);
      if(!el || !map[id]) return;
      el.value = map[id];
      if(id === 'inp-name' || id === 'inp-email' || id === 'inp-business') el.readOnly = true;
    });
  }

  function saveAssessment(){
    if(ctx.mode !== 'employee' || saveState.saved || saveState.saving) return Promise.resolve(true);
    if(typeof lastResults === 'undefined' || !lastResults || typeof state === 'undefined') return Promise.resolve(false);
    saveState.saving = true;
    saveState.resultCode = saveState.resultCode || ('GRM-' + Date.now().toString().slice(-10));
    var payload = Object.assign({}, lastResults, {
      assessment:'Growth-Readiness Matrix™',version:'current-upload',
      respondent:Object.assign({},lastResults.respondent||state.respondent||{}),
      answers:Object.assign({},lastResults.answers||state.answers||{}),
      summary:{'Founder Dependency Index':String(lastResults.overall??'')+' / 100',
        'Growth Potential':String(lastResults.growthScore??'')+' / 100',
        'Matrix Position':lastResults.quadrant&&lastResults.quadrant.label?lastResults.quadrant.label:''},
      submitted_at:new Date().toISOString()
    });
    return NovarisSubmission.post({product:'growth_readiness',result_code:saveState.resultCode,payload:payload});
  }

  function watchForCompletion(){
    var results = document.getElementById('screen-results');
    if(!results || ctx.mode !== 'employee') return;
    function maybeSave(){
      if(results.classList.contains('active')) {
        saveAssessment();
      }
    }
    new MutationObserver(maybeSave).observe(results, {attributes:true, attributeFilter:['class']});
    maybeSave();
  }

  function addAdminBackLink(){
    var back = document.createElement('a');
    back.href='index.php';
    back.textContent='← Novaris website';
    back.style.cssText='position:fixed;right:18px;top:18px;z-index:10000;background:#1A2E52;color:#fff;padding:10px 14px;border-radius:9px;text-decoration:none;font:700 12px Arial;box-shadow:0 8px 24px rgba(0,0,0,.16)';
    document.body.appendChild(back);
  }

  function openStoredResult(){
    var r = ctx.storedResult || {};
    if(!r.respondent || !r.answers || typeof state === 'undefined' || typeof computeAndShowResults !== 'function') {
      alert('This stored result does not contain the response detail required to rebuild the full Growth-Readiness report.');
      addAdminBackLink();
      return;
    }
    state.respondent = Object.assign({}, r.respondent);
    state.answers = Object.assign({}, r.answers);
    state.currentDim = 0;
    computeAndShowResults();
    var retake = document.querySelector('[onclick="restartTool()"]');
    if(retake) retake.style.display='none';
    addAdminBackLink();
  }

  document.addEventListener('DOMContentLoaded', function(){
    prefill();
    if(ctx.mode === 'review') openStoredResult();
    else watchForCompletion();
  });
})();
</script>
JS;
$overrideJs = str_replace(array_keys($values), array_values($values), $overrideJs);
$html = str_replace('</head>', '<link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><meta name="robots" content="noindex,nofollow"><meta http-equiv="Cache-Control" content="no-store"></head>', $html);
$html = novaris_insert_before_closing_body($html, $overrideJs);
$html = str_replace('</head>', '<link rel="stylesheet" href="assets/unified-assessments.css?v=20261013reportfix2"><link rel="stylesheet" href="assets/test-mobile.css"><script src="assets/unified-assessments.js?v=20261013reportfix2" defer></script><script src="assets/original-report-delivery.js?v=20261013reportfix2" defer></script></head>', $html);
$html = novaris_mark_document_body($html, 'growth_readiness');
echo $html;
