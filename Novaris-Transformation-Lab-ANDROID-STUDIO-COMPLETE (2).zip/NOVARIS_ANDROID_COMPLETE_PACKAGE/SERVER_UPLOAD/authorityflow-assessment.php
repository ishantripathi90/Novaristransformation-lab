<?php
require_once __DIR__ . '/assessment-bootstrap.php';
$ctx = novaris_assessment_page_context('authorityflow');
if (($ctx['mode'] ?? '') === 'employee_completed') {
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>AuthorityFlow submitted | Novaris Transformation Lab</title><?= novaris_portal_css() ?></head><body class="portal-body"><main class="portal-main"><div class="portal-shell"><div class="portal-card accent" style="max-width:760px;margin:40px auto;"><div class="portal-kicker">Assessment submitted</div><h1 class="portal-title">NOVARIS AuthorityFlow™ has already been completed.</h1><p class="portal-sub">Thank you, <?= novaris_h((string)($ctx['employee']['name'] ?? '')) ?>. Your completed result has been sent securely to Novaris.</p><p><a class="portal-btn" href="index.php">Close assessment →</a></p></div></div></main></body></html><?php
    exit;
}

$html = file_get_contents(__DIR__ . '/assessments/authorityflow/test.html');
if ($html === false) {
    http_response_code(500);
    exit('Assessment source file could not be loaded.');
}
$assignment = is_array($ctx['assignment'] ?? null) ? $ctx['assignment'] : [];
$storedResult = is_array($assignment['result'] ?? null) ? $assignment['result'] : [];
$values = [
    '__MODE__' => json_encode((string)($ctx['mode'] ?? 'employee')),
    '__EMPLOYEE_NAME__' => json_encode((string)($ctx['employee']['name'] ?? '')),
    '__EMPLOYEE_EMAIL__' => json_encode((string)($ctx['employee']['email'] ?? '')),
    '__COMPANY_NAME__' => json_encode((string)($ctx['company']['name'] ?? '')),
    '__EXTERNAL_ID__' => json_encode((string)($ctx['employee']['external_id'] ?? '')),
    '__DEPARTMENT__' => json_encode((string)($ctx['employee']['department'] ?? '')),
    '__STORED_RESULT__' => json_encode($storedResult, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
];
$overrideJs = <<<'JS'
<script>
window.NOVARIS_PLATFORM_CONTEXT = {
  product:'authorityflow',
  mode:__MODE__,
  employeeName:__EMPLOYEE_NAME__,
  employeeEmail:__EMPLOYEE_EMAIL__,
  companyName:__COMPANY_NAME__,
  externalId:__EXTERNAL_ID__,
  department:__DEPARTMENT__,
  storedResult:__STORED_RESULT__
};
(function(){
  var ctx = window.NOVARIS_PLATFORM_CONTEXT;
  var saveState = {saving:false,saved:false,resultCode:''};

  function setValue(id, value, lock){
    var el = document.getElementById(id);
    if(!el || !value) return;
    el.value = value;
    if(lock) el.readOnly = true;
  }

  function prefill(){
    if(ctx.mode !== 'employee') return;
    setValue('pname', ctx.employeeName, true);
    setValue('porg', ctx.companyName, true);
    setValue('prole', ctx.department || '', false);
    setValue('punit', ctx.department || '', false);
    setValue('pteam', ctx.externalId || '', false);
  }

  function buildPayload(){
    if(typeof answers === 'undefined' || typeof meta === 'undefined' || typeof score !== 'function') return null;
    var s = score();
    var xo = typeof executionOutcome === 'function' ? executionOutcome() : null;
    var summary = {};
    var dims = {};
    Object.keys(DIMS || {}).forEach(function(k){
      var label = DIMS[k][0];
      var val = s[k];
      var vis = typeof visibilityPct === 'function' ? visibilityPct(s,k) : null;
      summary[label] = val === null ? 'Insufficient visibility' : (String(val) + ' / 100 · ' + (typeof band === 'function' ? band(val) : ''));
      dims[k] = {name:label, score:val, visibility_pct:vis, judged:(s._counts && s._counts[k]) || 0, not_enough_visibility:(s._na && s._na[k]) || 0};
    });
    summary['Execution outcome signal'] = xo === null ? 'Insufficient visibility' : (String(xo) + ' / 100');
    return {
      assessment:'NOVARIS AuthorityFlow™ Organisational Authority & Execution Diagnostic',
      version:'2.8',
      meta:Object.assign({}, meta || {}),
      answers:Array.isArray(answers) ? answers.slice() : [],
      dimensions:dims,
      execution_outcome:xo,
      summary:summary,
      submitted_at:new Date().toISOString()
    };
  }

  function saveAssessment(){
    if(ctx.mode !== 'employee' || saveState.saved || saveState.saving) return Promise.resolve(true);
    var payload=buildPayload();
    if(!payload || !payload.answers.length || payload.answers.some(function(v){return v===null;})) return Promise.resolve(false);
    saveState.saving=true;
    saveState.resultCode=saveState.resultCode||('AF-'+Date.now().toString().slice(-10));
    return NovarisSubmission.post({product:'authorityflow',result_code:saveState.resultCode,payload:payload});
  }

  function watchForCompletion(){
    if(ctx.mode !== 'employee') return;
    var report = document.getElementById('reportsec');
    if(!report) return;
    function maybeSave(){
      if(!report.classList.contains('hide') && document.querySelectorAll('#report .page').length) {
        saveAssessment();
      }
    }
    new MutationObserver(maybeSave).observe(report,{attributes:true,attributeFilter:['class']});
    maybeSave();
  }

  function addAdminBackLink(){
    var back=document.createElement('a');
    back.href='index.php';
    back.textContent='← Novaris website';
    back.style.cssText='position:fixed;right:18px;top:18px;z-index:10000;background:#102a43;color:#fff;padding:10px 14px;border-radius:9px;text-decoration:none;font:700 12px Arial;box-shadow:0 8px 24px rgba(0,0,0,.16)';
    document.body.appendChild(back);
  }

  function useSiteLogo(){
    document.querySelectorAll('img.logo, .topin img, .reportbar img').forEach(function(img){ img.src='assets/novaris-original-solid.png'; });
  }

  function openStoredResult(){
    var r=ctx.storedResult || {};
    var storedAnswers = Array.isArray(r.answers) ? r.answers : (Array.isArray(r.responses) ? r.responses : null);
    if(!storedAnswers || storedAnswers.length !== 65 || !r.meta || typeof makeReport !== 'function') {
      alert('This result was created with an earlier AuthorityFlow version and cannot be rebuilt in the new 65-item AuthorityFlow report. Its stored summary cannot be rebuilt in this browser.');
      addAdminBackLink();
      return;
    }
    meta = Object.assign({}, r.meta);
    answers = storedAnswers.slice();
    var intro=document.getElementById('intro'); if(intro) intro.classList.add('hide');
    var assess=document.getElementById('assess'); if(assess) assess.classList.add('hide');
    useSiteLogo();
    makeReport();
    var reviewBtn=document.getElementById('backBtn'); if(reviewBtn) reviewBtn.style.display='none';
    addAdminBackLink();
  }

  document.addEventListener('DOMContentLoaded', function(){
    useSiteLogo();
    prefill();
    if(ctx.mode === 'employee' && typeof window.makeReport === 'function') {
      window.makeReport = function(){ saveAssessment(); };
    }
    if(ctx.mode === 'review') openStoredResult();
    else watchForCompletion();
  });
})();
</script>
JS;
$overrideJs = str_replace(array_keys($values), array_values($values), $overrideJs);
$html = str_replace('</head>', '<link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><meta name="robots" content="noindex,nofollow"><meta http-equiv="Cache-Control" content="no-store"></head>', $html);
$html = novaris_insert_before_closing_body($html, $overrideJs);
$html = str_replace('</head>', '<link rel="stylesheet" href="assets/unified-assessments.css?v=20261013reportfix2"><link rel="stylesheet" href="assets/test-mobile.css"><script src="assets/unified-assessments.js?v=20261013reportfix2" defer></script><script src="assets/original-report-delivery.js?v=20261013reportfix2" defer></script></head>', $html);
$html = novaris_mark_document_body($html, 'authorityflow');
echo $html;
