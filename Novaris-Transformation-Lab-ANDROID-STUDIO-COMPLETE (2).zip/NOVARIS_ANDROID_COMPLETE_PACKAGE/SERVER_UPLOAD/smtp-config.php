<?php
/**
 * Titan SMTP configuration for Novaris Transformation Lab.
 * Secrets are loaded from .env so this PHP file can stay non-secret.
 */
return [
    'host'       => getenv('NOVARIS_SMTP_HOST') ?: 'smtp.titan.email',
    'port'       => (int) (getenv('NOVARIS_SMTP_PORT') ?: 465),
    'encryption' => strtolower((string) (getenv('NOVARIS_SMTP_ENCRYPTION') ?: 'ssl')),
    'username'   => getenv('NOVARIS_SMTP_USERNAME') ?: 'lead@novaristransformationlab.com',
    'password'   => (string) (getenv('NOVARIS_SMTP_PASSWORD') ?: ''),
    'from_name'  => getenv('NOVARIS_SMTP_FROM_NAME') ?: 'Novaris Transformation Lab',
    'recipient'  => getenv('NOVARIS_SMTP_REPLY_TO') ?: 'lead@novaristransformationlab.com',
    'timeout'    => (int) (getenv('NOVARIS_SMTP_TIMEOUT') ?: 20),
];
