# Deploy the complete Novaris eight-assessment site

1. Back up the existing `public_html` site and mail configuration.
2. Remove the old website files to avoid old Razorpay/admin/report assets remaining live.
3. Upload the **contents** of the ZIP's `novaris-transformation-lab` folder into your actual website `public_html` document root.
4. The existing `.env` must remain private and readable by PHP. Make sure Titan SMTP credentials and outbound SMTP access are working. The only result recipient is `lead@novaristransformationlab.com`.
5. Confirm PHP upload settings: `upload_max_filesize` at least 24M, `post_max_size` at least 32M, `memory_limit` 192M or more, and a long enough request execution timeout. The package's `.user.ini` sets these values when supported by the hosting provider. If the host ignores `.user.ini`, configure the hosting PHP selector instead.
6. Clear browser caches / test in incognito on a phone and computer. Ensure each assessment opens without showing source code.
7. Complete a real assessment for **all eight instruments**. In the Novaris lead inbox, open and count the pages in the original PDF(s): MEridian 10+4, EQuilibrium 10+4, Entronovaris 12, AuthorityFlow 12, Growth Readiness 11, RELATIQ 12, Team Dynamics 10, Team Latitude 10. Page counts can vary if an authored report's content changes in the future.
8. Participants should see only the on-screen executive summary, never a PDF download. If the report or SMTP server fails, a Retry option appears. Look in PHP error logs if needed; do not share SMTP passwords.

**Limitations:** The full page generation was checked locally using the original score/report engines with a lightweight canvas substitute, not with every font and image fully rasterized on a real phone. Two-file server upload validation was tested against an intentionally unavailable local SMTP endpoint. Live Titan delivery and actual device rendering are not confirmed until you perform step 7.

See `ORIGINAL-REPORT-DELIVERY.md` for technical details. Keep the ZIP private because it includes `.env`.
