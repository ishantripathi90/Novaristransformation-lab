<?php
/**
 * Minimal self-contained SMTP client for Titan SMTP.
 * No Composer / PHPMailer dependency is required.
 *
 * Supports: EHLO, STARTTLS/SMTPS, AUTH LOGIN, multipart text+HTML email.
 */

final class TitanSmtpException extends RuntimeException {}

final class TitanSmtpClient
{
    private array $config;
    /** @var resource|null */
    private $socket = null;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function send(
        string $toEmail,
        string $toName,
        string $subject,
        string $htmlBody,
        string $textBody,
        ?string $replyToEmail = null,
        ?string $replyToName = null,
        array $attachments = []
    ): void {
        $this->connect();

        try {
            $fromEmail = (string) $this->config['username'];
            $fromName = (string) ($this->config['from_name'] ?? 'Novaris Transformation Lab');

            $this->command('MAIL FROM:<' . $this->smtpAddress($fromEmail) . '>', [250]);
            $this->command('RCPT TO:<' . $this->smtpAddress($toEmail) . '>', [250, 251]);
            $this->command('DATA', [354]);

            $message = $this->buildMessage(
                $fromEmail,
                $fromName,
                $toEmail,
                $toName,
                $subject,
                $htmlBody,
                $textBody,
                $replyToEmail,
                $replyToName,
                $attachments
            );

            // SMTP dot-stuffing: a line beginning with '.' must be prefixed with another '.'.
            $message = preg_replace('/(^|\r\n)\./', '$1..', $message) ?? $message;
            $this->write($message . "\r\n.\r\n");
            $this->expect([250]);
            $this->command('QUIT', [221]);
        } finally {
            $this->close();
        }
    }

    private function connect(): void
    {
        $host = (string) ($this->config['host'] ?? 'smtp.titan.email');
        $port = (int) ($this->config['port'] ?? 587);
        $encryption = strtolower((string) ($this->config['encryption'] ?? 'tls'));
        $timeout = (int) ($this->config['timeout'] ?? 20);

        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
                'peer_name' => $host,
                'SNI_enabled' => true,
                'allow_self_signed' => false,
            ],
        ]);

        $scheme = $encryption === 'ssl' ? 'ssl' : 'tcp';
        $remote = $scheme . '://' . $host . ':' . $port;
        $errno = 0;
        $errstr = '';
        $socket = @stream_socket_client(
            $remote,
            $errno,
            $errstr,
            $timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!is_resource($socket)) {
            throw new TitanSmtpException("Could not connect to SMTP server ({$errno}: {$errstr}).");
        }

        $this->socket = $socket;
        stream_set_timeout($this->socket, $timeout);
        $this->expect([220]);

        $ehloName = $this->ehloName();
        $this->command('EHLO ' . $ehloName, [250]);

        if ($encryption !== 'ssl') {
            $this->command('STARTTLS', [220]);
            $cryptoOk = @stream_socket_enable_crypto(
                $this->socket,
                true,
                STREAM_CRYPTO_METHOD_TLS_CLIENT
            );
            if ($cryptoOk !== true) {
                throw new TitanSmtpException('STARTTLS negotiation failed.');
            }
            // RFC requires EHLO again after STARTTLS.
            $this->command('EHLO ' . $ehloName, [250]);
        }

        $this->command('AUTH LOGIN', [334]);
        $this->command(base64_encode((string) $this->config['username']), [334], false);
        $this->command(base64_encode((string) $this->config['password']), [235], false);
    }

    private function buildMessage(
        string $fromEmail,
        string $fromName,
        string $toEmail,
        string $toName,
        string $subject,
        string $htmlBody,
        string $textBody,
        ?string $replyToEmail,
        ?string $replyToName,
        array $attachments = []
    ): string {
        $boundary = '=_Novaris_' . bin2hex(random_bytes(16));
        $mixedBoundary = '=_Novaris_Files_' . bin2hex(random_bytes(16));
        $domain = $this->messageIdDomain($fromEmail);
        $messageId = '<' . bin2hex(random_bytes(12)) . '.' . time() . '@' . $domain . '>';

        $headers = [
            'Date: ' . date(DATE_RFC2822),
            'Message-ID: ' . $messageId,
            'From: ' . $this->formatMailbox($fromEmail, $fromName),
            'To: ' . $this->formatMailbox($toEmail, $toName),
        ];

        if ($replyToEmail !== null && $replyToEmail !== '') {
            $headers[] = 'Reply-To: ' . $this->formatMailbox($replyToEmail, $replyToName ?? '');
        }

        $headers[] = 'Subject: ' . $this->encodeHeader($subject);
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = $attachments
            ? 'Content-Type: multipart/mixed; boundary="' . $mixedBoundary . '"'
            : 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
        $headers[] = 'X-Mailer: Novaris Titan SMTP PHP';

        $body = [];
        if ($attachments) {
            $body[] = '--' . $mixedBoundary;
            $body[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
            $body[] = '';
        }
        $body[] = '--' . $boundary;
        $body[] = 'Content-Type: text/plain; charset=UTF-8';
        $body[] = 'Content-Transfer-Encoding: base64';
        $body[] = '';
        $body[] = rtrim(chunk_split(base64_encode($textBody), 76, "\r\n"));
        $body[] = '--' . $boundary;
        $body[] = 'Content-Type: text/html; charset=UTF-8';
        $body[] = 'Content-Transfer-Encoding: base64';
        $body[] = '';
        $body[] = rtrim(chunk_split(base64_encode($htmlBody), 76, "\r\n"));
        $body[] = '--' . $boundary . '--';
        foreach ($attachments as $attachment) {
            $filename = basename((string)($attachment['filename'] ?? 'Novaris_Report.pdf'));
            $filename = preg_replace('/[^A-Za-z0-9_.-]/', '_', $filename) ?: 'Novaris_Report.pdf';
            $content = (string)($attachment['content'] ?? '');
            if ($content === '' || strlen($content) > 17000000) {
                throw new TitanSmtpException('Invalid or oversized email attachment.');
            }
            $mime = (string)($attachment['mime'] ?? 'application/pdf');
            if (!preg_match('~^[A-Za-z0-9.-]+/[A-Za-z0-9.+-]+$~', $mime)) $mime = 'application/octet-stream';
            $body[] = '--' . $mixedBoundary;
            $body[] = 'Content-Type: ' . $mime . '; name="' . $filename . '"';
            $body[] = 'Content-Transfer-Encoding: base64';
            $body[] = 'Content-Disposition: attachment; filename="' . $filename . '"';
            $body[] = '';
            $body[] = rtrim(chunk_split(base64_encode($content), 76, "\r\n"));
        }
        if ($attachments) $body[] = '--' . $mixedBoundary . '--';

        return implode("\r\n", $headers) . "\r\n\r\n" . implode("\r\n", $body);
    }

    private function command(string $command, array $expectedCodes, bool $safeToLog = true): string
    {
        $this->write($command . "\r\n");
        return $this->expect($expectedCodes, $safeToLog ? $command : '[credential]');
    }

    private function expect(array $expectedCodes, string $context = ''): string
    {
        if (!is_resource($this->socket)) {
            throw new TitanSmtpException('SMTP connection is not open.');
        }

        $response = '';
        $code = null;

        while (($line = fgets($this->socket, 515)) !== false) {
            $response .= $line;
            if (preg_match('/^(\d{3})([ -])/', $line, $m)) {
                $code = (int) $m[1];
                if ($m[2] === ' ') {
                    break;
                }
            }
        }

        $meta = stream_get_meta_data($this->socket);
        if (!empty($meta['timed_out'])) {
            throw new TitanSmtpException('SMTP server timed out while waiting for a response.');
        }

        if ($code === null || !in_array($code, $expectedCodes, true)) {
            $clean = trim(preg_replace('/\s+/', ' ', $response) ?? $response);
            $suffix = $context !== '' ? ' after ' . $context : '';
            throw new TitanSmtpException('Unexpected SMTP response' . $suffix . ': ' . $clean);
        }

        return $response;
    }

    private function write(string $data): void
    {
        if (!is_resource($this->socket)) {
            throw new TitanSmtpException('SMTP connection is not open.');
        }

        $length = strlen($data);
        $written = 0;
        while ($written < $length) {
            $n = fwrite($this->socket, substr($data, $written));
            if ($n === false || $n === 0) {
                throw new TitanSmtpException('Could not write to SMTP server.');
            }
            $written += $n;
        }
    }

    private function close(): void
    {
        if (is_resource($this->socket)) {
            fclose($this->socket);
        }
        $this->socket = null;
    }

    private function formatMailbox(string $email, string $name): string
    {
        $email = $this->smtpAddress($email);
        $name = trim(str_replace(["\r", "\n"], ' ', $name));
        return $name === '' ? '<' . $email . '>' : $this->encodeHeader($name) . ' <' . $email . '>';
    }

    private function encodeHeader(string $value): string
    {
        $value = trim(str_replace(["\r", "\n"], ' ', $value));
        if ($value === '') {
            return '';
        }
        if (function_exists('mb_encode_mimeheader')) {
            return mb_encode_mimeheader($value, 'UTF-8', 'B', "\r\n");
        }
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    private function smtpAddress(string $email): string
    {
        $email = trim(str_replace(["\r", "\n", '<', '>'], '', $email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new TitanSmtpException('Invalid email address supplied to SMTP client.');
        }
        return $email;
    }

    private function ehloName(): string
    {
        $host = $_SERVER['SERVER_NAME'] ?? gethostname() ?: 'localhost';
        $host = preg_replace('/[^A-Za-z0-9.-]/', '', (string) $host) ?: 'localhost';
        return $host;
    }

    private function messageIdDomain(string $fromEmail): string
    {
        $parts = explode('@', $fromEmail, 2);
        return isset($parts[1]) && $parts[1] !== '' ? $parts[1] : 'localhost';
    }
}
