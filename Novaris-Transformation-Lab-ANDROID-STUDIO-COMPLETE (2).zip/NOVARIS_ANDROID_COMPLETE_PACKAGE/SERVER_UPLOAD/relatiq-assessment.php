<?php
require_once __DIR__ . '/assessment-bootstrap.php';

$ctx = novaris_assessment_page_context('relatiq');
$mode = (string) ($ctx['mode'] ?? '');

if ($mode === 'employee_completed') {
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RELATIQ™ submitted | Novaris Transformation Lab</title><?= novaris_portal_css() ?></head><body class="portal-body"><header class="portal-header"><div class="portal-shell in"><a href="index.php"><img class="portal-logo" src="assets/novaris-original-solid.png" alt="Novaris Transformation Lab"></a></div></header><main class="portal-main"><div class="portal-shell"><div class="portal-card accent" style="max-width:760px;margin:40px auto;"><div class="portal-kicker">Assessment submitted</div><h1 class="portal-title">NOVARIS RELATIQ™ has already been completed.</h1><p class="portal-sub">Thank you, <?= novaris_h((string)($ctx['employee']['name'] ?? '')) ?>. Your completed result has been sent securely to Novaris.</p><p><a class="portal-btn" href="index.php">Close assessment →</a></p></div></div></main></body></html><?php
    exit;
}

$html = file_get_contents(__DIR__ . '/assessments/relatiq/test.html');
if ($html === false) {
    http_response_code(500);
    exit('Assessment source file could not be loaded.');
}

$employee = is_array($ctx['employee'] ?? null) ? $ctx['employee'] : [];
$assignment = is_array($ctx['assignment'] ?? null) ? $ctx['assignment'] : [];
$storedResult = is_array($assignment['result'] ?? null) ? $assignment['result'] : [];

$portal = [
    'mode' => $mode,
    'name' => (string) ($employee['name'] ?? ($storedResult['respondent']['name'] ?? '')),
    'email' => (string) ($employee['email'] ?? ($storedResult['respondent']['email'] ?? '')),
    'company' => (string) (($ctx['company']['name'] ?? '')),
    'assignment_id' => (string) ($assignment['id'] ?? ''),
    'stored' => $storedResult,
];
$portalJson = json_encode($portal, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

$bridge = <<<'JS'
<script>
window.NOVARIS_RELATIQ_PORTAL = __PORTAL_JSON__;
(function(){
  var portal = window.NOVARIS_RELATIQ_PORTAL || {};
  var saveInFlight = null;
  var saved = false;

  function scoreSummary(scores){
    scores = scores || {};
    var pct = scores.pct || {};
    var diff = scores.differences || {};
    return {
      'Social Initiative': pct.eI == null ? '' : pct.eI + ' / 100',
      'Belonging Need': pct.wI == null ? '' : pct.wI + ' / 100',
      'Direction Drive': pct.eC == null ? '' : pct.eC + ' / 100',
      'Structure Need': pct.wC == null ? '' : pct.wC + ' / 100',
      'Relational Openness': pct.eA == null ? '' : pct.eA + ' / 100',
      'Connection Need': pct.wA == null ? '' : pct.wA + ' / 100',
      'ENGAGE reciprocity difference': diff.ENGAGE == null ? '' : diff.ENGAGE,
      'DIRECT reciprocity difference': diff.DIRECT == null ? '' : diff.DIRECT,
      'CONNECT reciprocity difference': diff.CONNECT == null ? '' : diff.CONNECT
    };
  }

  function saveResult(){
    if(portal.mode !== 'employee' || saved){ return Promise.resolve(); }
    if(saveInFlight){ return saveInFlight; }
    var scores=(typeof computeScores==='function')?computeScores():{};
    var payload={assessment:'NOVARIS RELATIQ™',
      respondent:{name:user.name||portal.name||'',email:user.email||portal.email||''},
      answers:Object.assign({},answers||{}),scores:scores,summary:scoreSummary(scores),
      submitted_at:new Date().toISOString()};
    saveInFlight=NovarisSubmission.post({product:'relatiq',result_code:'REL-'+Date.now().toString().slice(-9),payload:payload});
    return saveInFlight;
  }

  function lockIdentity(){
    if(portal.mode !== 'employee'){ return; }
    if(typeof user !== 'undefined'){
      user.name = portal.name || user.name || '';
      user.email = portal.email || user.email || '';
    }
    var nameInput = document.getElementById('nameInput');
    var emailInput = document.getElementById('emailInput');
    if(nameInput){ nameInput.value = portal.name || ''; nameInput.readOnly = true; }
    if(emailInput){ emailInput.value = portal.email || ''; emailInput.readOnly = true; }
  }

  if(portal.mode === 'employee'){
    lockIdentity();
    var originalBuildReport = window.buildReport;
    window.buildReport = function(){
      if(window.NovarisSubmission)window.NovarisSubmission.showPending();
      originalBuildReport.apply(this,arguments);
      saveResult();
    };
  }

  if(portal.mode === 'review'){
    var stored = portal.stored || {};
    if(typeof answers !== 'undefined'){ answers = Object.assign({}, stored.answers || {}); }
    if(typeof user !== 'undefined'){
      var respondent = stored.respondent || {};
      user = {name:respondent.name || portal.name || '', email:respondent.email || portal.email || ''};
    }
    if(Object.keys(answers || {}).length){
      state.screen = 'report';
      buildReport();
      var backBtn = document.getElementById('backBtn');
      if(backBtn){ backBtn.textContent = '← Novaris website'; backBtn.onclick = function(){ location.href='index.php'; }; }
    }else{
      document.getElementById('screen').innerHTML = '<div class="card intro"><h1>Stored report unavailable</h1><p>The result summary exists, but the response detail needed to rebuild this RELATIQ report is not available.</p><a class="btn" href="index.php">Return to Novaris website</a></div>';
    }
  }
})();
</script>
JS;
$bridge = str_replace('__PORTAL_JSON__', $portalJson ?: '{}', $bridge);
$html = novaris_insert_before_closing_body($html, $bridge . "\n");
$html = str_replace('</head>', '<link rel="icon" href="/favicon.ico?v=20261010triangle" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="apple-mobile-web-app-title" content="Novaris">
<meta name="theme-color" content="#ffffff"><link rel="stylesheet" href="assets/unified-assessments.css?v=20261013reportfix2"><link rel="stylesheet" href="assets/test-mobile.css"><script src="assets/unified-assessments.js?v=20261013reportfix2" defer></script><script src="assets/original-report-delivery.js?v=20261013reportfix2" defer></script></head>', $html);
$html = novaris_mark_document_body($html, 'relatiq');
echo $html;
